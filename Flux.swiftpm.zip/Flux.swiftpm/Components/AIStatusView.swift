//
//  AIStatusView.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//  This view shows the current Apple Intelligence generation status to the user.

import SwiftUI

struct AIStatusView: View {
    // Binding driven by the parent to indicate whether AI generation is running
    @Binding var isAIGenerating: Bool
    
    var body: some View {
        VStack {
            if isAIGenerating == true {
                Image(systemName: "sparkles")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 48)
                    .padding(.top)
                    .padding(.bottom)
                
                Text("Apple Intelligence is currently generating the content for your sub-bubbles. This process may take a few seconds.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            } else {
                Image(systemName: "checkmark.seal.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 48)
                    .padding(.top)
                    .padding(.bottom)
                
                Text("Apple Intelligence has finished generating the content for your sub-bubbles.")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
        }
        .padding()
    }
}
    
    #Preview {
        AIStatusView(isAIGenerating: .constant(true))
    }
