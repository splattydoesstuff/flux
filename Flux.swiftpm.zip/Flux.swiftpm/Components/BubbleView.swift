//
//  BubbleView.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//

import SwiftUI

struct LiquidBlob: View {
    var size: CGFloat
    let circleCount = 6
    @State private var offsets: [CGSize] = Array(repeating: .zero, count: 6)
    @State private var scale: CGFloat = 0.01
    
    var body: some View {
        ZStack {
            Circle().fill(.white).frame(width: size, height: size)
            ForEach(0..<circleCount, id: \.self) { index in
                Circle().fill(.white)
                    .frame(width: size * 0.7, height: size * 0.7)
                    .offset(offsets[index])
            }
        }
        .scaleEffect(scale)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                scale = 1.0
            }
            for i in 0..<circleCount {
                withAnimation(.easeInOut(duration: Double.random(in: 2...4)).repeatForever()) {
                    offsets[i] = CGSize(
                        width: CGFloat.random(in: -size/4...size/4),
                        height: CGFloat.random(in: -size/4...size/4)
                    )
                }
            }
        }
    }
}

struct MetaBallCanvas: View {
    var items: [MainBubbleItem]
    var sizeResolver: (MainBubbleItem) -> CGFloat
    // New: allow the caller to provide a per-item scale (used when a bubble is being held)
    var scaleResolver: (MainBubbleItem) -> CGFloat = { _ in 1.0 }
    
    var body: some View {
        TimelineView(.animation) { _ in
            Canvas { context, size in
                context.addFilter(.alphaThreshold(min: 0.5, color: .white))
                context.addFilter(.blur(radius: 35))
                
                context.drawLayer { ctx in
                    let center = CGPoint(x: size.width / 2, y: size.height / 2)
                    for item in items {
                        if let symbol = context.resolveSymbol(id: item.id) {
                            let pos = CGPoint(x: center.x + item.offset.width, y: center.y + item.offset.height)
                            ctx.draw(symbol, at: pos)
                        }
                    }
                }
            } symbols: {
                ForEach(items) { item in
                    // Apply the size resolver and then a scaleEffect driven by the scaleResolver
                    LiquidBlob(size: sizeResolver(item))
                        .scaleEffect(scaleResolver(item))
                        .tag(item.id)
                }
            }
            .opacity(0.4)
        }
    }
}

struct MetaBallCanvasWithSubBubbles: View {
    var centerItem: MainBubbleItem
    var subBubbles: [BubbleData]
    var centerSize: CGFloat
    var subSize: CGFloat
    var centerScale: CGFloat
    var snappingBubbleID: UUID?
    
    var body: some View {
        TimelineView(.animation) { _ in
            Canvas { context, size in
                context.addFilter(.alphaThreshold(min: 0.5, color: .white))
                context.addFilter(.blur(radius: 35))
                
                context.drawLayer { ctx in
                    let center = CGPoint(x: size.width / 2, y: size.height / 2)
                    let mainPos = CGPoint(x: center.x + centerItem.offset.width, y: center.y + centerItem.offset.height)
                    
                    if let mainSym = context.resolveSymbol(id: "MAIN") {
                        ctx.draw(mainSym, at: mainPos)
                    }
                    
                    for sub in subBubbles {
                        if let subSym = context.resolveSymbol(id: sub.id) {
                            ctx.draw(subSym, at: mainPos)
                        }
                    }
                }
            } symbols: {
                LiquidBlob(size: centerSize).scaleEffect(centerScale).tag("MAIN")
                
                ForEach(subBubbles) { sub in
                    let isSnapping = (sub.id == snappingBubbleID)
                    
                    LiquidBlob(size: subSize)
                        .scaleEffect(isSnapping ? 0.01 : 1.0)
                        .offset(sub.offset)
                        .tag(sub.id)
                }
            }
            .opacity(0.4)
            .animation(.spring(response: 0.4, dampingFraction: 0.7), value: snappingBubbleID)
        }
    }
}
