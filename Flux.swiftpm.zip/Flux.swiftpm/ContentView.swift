import SwiftUI

struct ContentView: View {
    @AppStorage("isWelcomeSheetShowing") var isWelcomeSheetShowing: Bool = true
    
    var body: some View {
        TabView {
            Tab("My Sky", systemImage: "cloud.fill") {
                HomeView()
                    .sheet(isPresented: $isWelcomeSheetShowing) {
                        WelcomeSheetView(isWelcomeSheetShowing: $isWelcomeSheetShowing)
                    }
            }
            
            Tab("About", systemImage: "questionmark.circle.dashed") {
                AboutView()
            }
        }
        .preferredColorScheme(.dark)
    }
}
