//
//  IntelligenceCheckView.swift
//  Flux
//
//  Created by Asia Ciafardini on 06/02/26.
//  This helper checks if the device is supported by Apple Intelligence and its installation status.

import SwiftUI
import FoundationModels

struct IntelligenceCheckView: View {
    @State var session = LanguageModelSession {
        """
        You're an intelligence living in a sky full of bubbles. You help the user managing their schedule by breaking down bubbles (tasks) in multiple sub-bubbles (sub-tasks) containing useful and meaningful steps to completing the task.
        """
    }
    
    var body: some View {
        switch SystemLanguageModel.default.availability {
        case .available:
            VStack {
                Spacer()
                
                Image(systemName: "apple.intelligence")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .opacity(0.7)
                
                Text("The language model is available and ready! Try it out.")
                    .font(.title2).bold()
                    .multilineTextAlignment(.center)
                    .padding()
                
                Spacer()
            }
        case .unavailable(let reason):
            let text = switch reason {
            case .appleIntelligenceNotEnabled:
                "Apple Intelligence is not enabled. Please enable it in Settings."
            case .deviceNotEligible:
                "This device is not eligible for Apple Intelligence. Please use a compatible device."
            case .modelNotReady:
                "The language model is not ready yet. Please try again later."
            @unknown default:
                "The language model is unavailable for an unknown reason."
            }
            ContentUnavailableView(text, systemImage: "apple.intelligence.badge.xmark")
        }
    }
}

#Preview {
    IntelligenceCheckView()
}
