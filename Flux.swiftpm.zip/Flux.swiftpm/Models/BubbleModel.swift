//
//  BubbleModel.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//

import SwiftUI

struct BubbleData: Identifiable, Codable, Equatable {
    var id = UUID()
    var offset: CGSize = .zero
    var lastOffset: CGSize = .zero
    var color: String = "white"
    var emoji: String
    var taskNote: String
    var isCustom: Bool = false
}

struct MainBubbleItem: Identifiable, Equatable, Codable {
    var id = UUID()
    var title: String
    var emoji: String
    var subBubbles: [BubbleData]
    var offset: CGSize = .zero
    var lastOffset: CGSize = .zero
}
