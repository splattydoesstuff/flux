//
//  BubbleModel.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//

import SwiftUI
import SwiftData

struct BubbleData: Identifiable, Codable, Equatable {
    var id = UUID()
    var offset: CGSize = .zero
    var lastOffset: CGSize = .zero
    var color: String = "white"
    var emoji: String
    var taskNote: String
    var isCustom: Bool = false
}

@Model
final class MainBubbleItem: Identifiable, Equatable {
    var id: UUID = UUID()
    var title: String = ""
    var emoji: String = ""
    var subBubbles: [BubbleData] = []
    var offsetX: Double = 0.0
    var offsetY: Double = 0.0
    var lastOffsetX: Double = 0.0
    var lastOffsetY: Double = 0.0
    
    @Transient
    var offset: CGSize {
        get { CGSize(width: offsetX, height: offsetY) }
        set {
            offsetX = Double(newValue.width)
            offsetY = Double(newValue.height)
        }
    }
    
    @Transient
    var lastOffset: CGSize {
        get { CGSize(width: lastOffsetX, height: lastOffsetY) }
        set {
            lastOffsetX = Double(newValue.width)
            lastOffsetY = Double(newValue.height)
        }
    }
    
    init(id: UUID = UUID(),
         title: String,
         emoji: String,
         subBubbles: [BubbleData] = [],
         offset: CGSize = .zero,
         lastOffset: CGSize = .zero) {
        
        self.id = id
        self.title = title
        self.emoji = emoji
        self.subBubbles = subBubbles
        self.offsetX = Double(offset.width)
        self.offsetY = Double(offset.height)
        self.lastOffsetX = Double(lastOffset.width)
        self.lastOffsetY = Double(lastOffset.height)
    }
    
    static func == (lhs: MainBubbleItem, rhs: MainBubbleItem) -> Bool {
        lhs.id == rhs.id
    }
}
