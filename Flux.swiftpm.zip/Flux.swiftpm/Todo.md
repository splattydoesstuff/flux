# Todo

- Sistemare system prompt
