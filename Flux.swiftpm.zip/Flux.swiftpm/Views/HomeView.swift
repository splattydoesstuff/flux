//
//  HomeView.swift
//  Flux
//
//  Created by Asia Ciafardini on 03/02/26.
//

import SwiftUI
import SwiftData
import FoundationModels
import UIKit
import Vortex

// MARK: UIEmojiTextField & Representable
class UIEmojiTextField: UITextField {
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setEmoji() {
        _ = self.textInputMode
    }
    
    override var textInputContextIdentifier: String? {
           return ""
    }
    
    override var textInputMode: UITextInputMode? {
        for mode in UITextInputMode.activeInputModes {
            if mode.primaryLanguage == "emoji" {
                self.keyboardType = .default
                return mode
            }
        }
        return nil
    }
}

struct EmojiTextField: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String = ""
    
    func makeUIView(context: Context) -> UIEmojiTextField {
        let emojiTextField = UIEmojiTextField()
        emojiTextField.placeholder = placeholder
        emojiTextField.text = text
        emojiTextField.delegate = context.coordinator
        emojiTextField.font = .systemFont(ofSize: 17)
        return emojiTextField
    }
    
    func updateUIView(_ uiView: UIEmojiTextField, context: Context) {
        uiView.text = text
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    class Coordinator: NSObject, UITextFieldDelegate {
        var parent: EmojiTextField
        
        init(parent: EmojiTextField) {
            self.parent = parent
        }
        
        func textFieldDidChangeSelection(_ textField: UITextField) {
            DispatchQueue.main.async { [weak self] in
                self?.parent.text = textField.text ?? ""
            }
        }
    }
}

// MARK: Emoji extension
extension Character {
    var isEmoji: Bool {
        guard let scalar = unicodeScalars.first else { return false }
        return scalar.properties.isEmoji && (scalar.value >= 0x203C || scalar.properties.isEmojiPresentation)
    }
}

// MARK: CreateTaskView (sheet)
struct CreateTaskView: View {
    @Binding var emojiInput: String
    @Binding var titleInput: String
    @Binding var editingProjectID: UUID?

    var onCreate: () -> Void
    var onSave: (UUID) -> Void
    var onCancel: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Text(editingProjectID == nil ? "New Bubble" : "Edit Bubble")
                .font(.title).bold()
                .padding()
            
            EmojiTextField(text: $emojiInput, placeholder: "Icon (e.g. 🪐)")
                .frame(height: 55)
                .padding(.horizontal)
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
                .onChange(of: emojiInput) { _ , newValue in
                    guard !newValue.isEmpty else { return }
                    if let lastChar = newValue.last {
                        if lastChar.isEmoji {
                            if emojiInput != String(lastChar) { emojiInput = String(lastChar) }
                        } else {
                            let filtered = newValue.filter { $0.isEmoji }
                            emojiInput = filtered
                        }
                    }
                }

            TextField("Title", text: $titleInput)
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))

            HStack(spacing: 12) {
                Button(role: .cancel) { onCancel() } label: {
                    Text("Cancel").frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
                }

                Button(editingProjectID == nil ? "Create" : "Save") {
                    if let id = editingProjectID { onSave(id) } else { onCreate() }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(Color.accentColor.opacity(0.2)))
            }
            .padding(.horizontal)
        }
        .padding()
    }
}

// MARK: HomeView
struct HomeView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var projects: [MainBubbleItem]
    
    @State private var selectedProjectID: UUID?
    @State private var tempEmojiInput = ""
    @State private var tempTitleInput = ""
    @State private var editingProjectID: UUID?
    @State private var showProjectSheet: Bool = false
    @State private var contextProjectSnapshot: MainBubbleItem?
    @State private var animateRainbow: Bool = false
    @State private var showConfetti: Bool = false
    @State private var holdingProjectID: UUID? = nil
    @State private var mainCenterScale: CGFloat = 1.0
    @State private var isHoldingMain: Bool = false
    
    @State private var contextTask: Task<Void, Never>? = nil
    @State private var draggingProjectID: UUID? = nil

    private let calmGradient = LinearGradient(colors: [Color("BGrad1"), Color("BGrad2")], startPoint: .top, endPoint: .bottom)
    private let rainGradient = LinearGradient(colors: [Color("BGrad3"), Color("BGrad4")], startPoint: .top, endPoint: .bottom)
    let rainbowGradient = LinearGradient(colors: [Color("BowGradient1"), Color("BowGradient2")], startPoint: .topLeading, endPoint: .bottomTrailing)
    private let mainBubbleSize: CGFloat = 160

    var body: some View {
        mainView
    }

    private var mainView: some View {
        NavigationStack {
            ZStack {
                backgroundLayer

                if projects.isEmpty && !showConfetti {
                    emptyStateView
                } else {
                    MetaBallCanvas(items: projects, sizeResolver: { _ in mainBubbleSize }, scaleResolver: { item in
                        if item.id == holdingProjectID {
                            return mainCenterScale * (isHoldingMain ? 1.05 : 1.0)
                        }
                        return 1.0
                    })
                        .ignoresSafeArea()

                    interactionLayer
                }
            }
            .navigationTitle("My Sky")
            .navigationDestination(isPresented: Binding(
                get: { selectedProjectID != nil },
                set: { if !$0 { selectedProjectID = nil } }
            )) {
                if let id = selectedProjectID, let project = projects.first(where: { $0.id == id }) {
                    TaskViewBridge(
                        project: project,
                        onDelete: {
                            removeProject(id: id)
                            selectedProjectID = nil
                        },
                        onSave: {
                            try? modelContext.save()
                        }
                    )
                }
            }
            .toolbar { toolbarContent }
            .onChange(of: tempEmojiInput) { oldValue, newValue in
                guard !newValue.isEmpty else { return }
                if let lastChar = newValue.last {
                    if lastChar.isEmoji {
                        if tempEmojiInput != String(lastChar) { tempEmojiInput = String(lastChar) }
                    } else { tempEmojiInput = oldValue }
                }
            }
            .displayConfetti(isActive: $showConfetti)
            .sheet(isPresented: $showProjectSheet) {
                CreateTaskView(
                    emojiInput: $tempEmojiInput,
                    titleInput: $tempTitleInput,
                    editingProjectID: $editingProjectID,
                    onCreate: {
                        addProject(emoji: tempEmojiInput, title: tempTitleInput)
                        showProjectSheet = false
                    }, onSave: { id in
                        updateProject(id: id, emoji: tempEmojiInput, title: tempTitleInput)
                        showProjectSheet = false
                    }, onCancel: { showProjectSheet = false }
                )
                .presentationDetents([.medium])
            }
            .sheet(item: $contextProjectSnapshot) { project in
                ContextMenuView(
                    project: project,
                    tempEmojiInput: $tempEmojiInput,
                    tempTitleInput: $tempTitleInput,
                    editingProjectID: $editingProjectID,
                    contextProjectSnapshot: $contextProjectSnapshot,
                    showProjectSheet: $showProjectSheet,
                    onDelete: { id in triggerDeleteAnimation(for: id) }
                )
            }
        }
    }
}

// MARK: Subviews (file-scope extension)
private extension HomeView {
    @ViewBuilder
    var backgroundLayer: some View {
        calmGradient.ignoresSafeArea()

        rainGradient.ignoresSafeArea()
            .opacity(!projects.isEmpty && !showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 1.0), value: projects.isEmpty)

        if !projects.isEmpty && !showConfetti {
            VortexView(.rain) { Circle().fill(.white).frame(width: 32).tag("circle") }
                .ignoresSafeArea()
                .transition(.opacity.animation(.easeInOut(duration: 1.0)))
        }

        rainbowGradient
            .hueRotation(.degrees(animateRainbow ? 360 : 0))
            .ignoresSafeArea()
            .opacity(showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 0.5), value: showConfetti)
            .onChange(of: showConfetti) { _, isActive in
                if isActive {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) { animateRainbow = true }
                } else { animateRainbow = false }
            }
    }

    var emptyStateView: some View {
        ContentUnavailableView("No Bubbles", systemImage: "bubbles.and.sparkles", description: Text("Tap + to add a new Bubble."))
            .transition(.opacity)
    }

    @ViewBuilder
    var interactionLayer: some View {
        GeometryReader { proxy in
            let center = CGPoint(x: proxy.size.width / 2, y: proxy.size.height / 2)

            ZStack {
                ForEach(projects) { project in

                    Circle()
                        .fill(Color.white.opacity(0.001))
                        .frame(width: mainBubbleSize, height: mainBubbleSize)
                        .offset(project.offset)
                        .position(center)
                        .simultaneousGesture(
                            DragGesture()
                                .onChanged { gesture in
                                    let current = project.lastOffset
                                    let t = gesture.translation
                                    project.offset = CGSize(width: current.width + t.width, height: current.height + t.height)

                                    draggingProjectID = project.id
                                    contextTask?.cancel()
                                    contextTask = nil
                                }
                                .onEnded { _ in
                                    project.lastOffset = project.offset
                                    if draggingProjectID == project.id { draggingProjectID = nil }
                                    try? modelContext.save()
                                }
                        )
                        .onLongPressGesture(minimumDuration: 1.0, pressing: { isPressing in
                            withAnimation(.easeInOut(duration: 0.2)) {
                                isHoldingMain = isPressing
                            }

                            if isPressing {
                                holdingProjectID = project.id
                                let startGen = UIImpactFeedbackGenerator(style: .light)
                                startGen.impactOccurred()

                                contextTask?.cancel()
                                
                                contextTask = Task { @MainActor in
                                    do {
                                        try await Task.sleep(for: .seconds(0.5))
                                        
                                        if draggingProjectID == nil {
                                            let shownGen = UIImpactFeedbackGenerator(style: .medium)
                                            shownGen.impactOccurred()
                                            contextProjectSnapshot = project
                                        }
                                    } catch {
                                        // Task cancelled, do nothing
                                    }
                                }
                            } else {
                                contextTask?.cancel()
                                contextTask = nil
                                 
                                if contextProjectSnapshot == nil {
                                    if holdingProjectID == project.id { holdingProjectID = nil }
                                }
                            }
                        }, perform: {})
                        .highPriorityGesture(TapGesture().onEnded { _ in
                            if contextProjectSnapshot == nil {
                                selectedProjectID = project.id
                            }
                        })

                    ZStack {
                        Text(project.emoji)
                            .font(.system(size: mainBubbleSize * 0.3))
                            .scaleEffect(holdingProjectID == project.id ? (isHoldingMain ? 1.1 : 1.0) : 1.0)
                            .offset(y: -45)
                            .animation(.spring(response: 0.5, dampingFraction: 0.7), value: holdingProjectID)

                        Text(project.title).font(.system(size: 16, weight: .bold, design: .rounded)).offset(y: 55)
                    }
                    .position(x: center.x + project.offset.width, y: center.y + project.offset.height)
                    .allowsHitTesting(false)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
    }

    @ToolbarContentBuilder
    var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .primaryAction) {
            Button(action: {
                tempEmojiInput = ""
                tempTitleInput = ""
                editingProjectID = nil
                showProjectSheet = true
            }) { Image(systemName: "plus") }
        }
    }
}

// MARK: Helpers & Data Management
private extension HomeView {
    func addProject(emoji: String, title: String) {
        let finalEmoji = emoji.isEmpty ? "🪐" : emoji
        let finalTitle = title.isEmpty ? "Project" : title
        let randomX = CGFloat.random(in: -100...100)
        let randomY = CGFloat.random(in: -200...200)
        
        let newProject = MainBubbleItem(
            title: finalTitle,
            emoji: finalEmoji,
            subBubbles: [],
            offset: CGSize(width: randomX, height: randomY),
            lastOffset: CGSize(width: randomX, height: randomY)
        )
        
        modelContext.insert(newProject)
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            try? modelContext.save()
        }
    }
    
    func updateProject(id: UUID, emoji: String, title: String) {
        if let project = projects.first(where: { $0.id == id }) {
            project.emoji = emoji
            project.title = title
            try? modelContext.save()
        }
    }
    
    func removeProject(id: UUID) {
        if let project = projects.first(where: { $0.id == id }) {
            modelContext.delete(project)
            
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                try? modelContext.save()
            }
        }
    }

    func triggerDeleteAnimation(for id: UUID) {
        withAnimation { showConfetti = true }
        removeProject(id: id)
        
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(2.5))
            withAnimation { showConfetti = false }
        }
    }
}

// MARK: Compiler Helper View
struct TaskViewBridge: View {
    @Bindable var project: MainBubbleItem
    var onDelete: () -> Void
    var onSave: () -> Void
    
    var body: some View {
        TaskView(project: project, onDelete: onDelete, onSave: onSave)
    }
}

#Preview {
    HomeView()
        .modelContainer(for: MainBubbleItem.self, inMemory: true)
}
