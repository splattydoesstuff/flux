//
//  HomeView.swift
//  Flux
//
//  Created by Asia Ciafardini on 03/02/26.
//

import SwiftUI
import FoundationModels
import UIKit
import Vortex

// MARK: Emoji extension
extension Character {
    var isEmoji: Bool {
        guard let scalar = unicodeScalars.first else { return false }
        return scalar.properties.isEmoji && (scalar.value >= 0x203C || scalar.properties.isEmojiPresentation)
    }
}

// MARK: AppData
class AppData {
    @MainActor static let shared = AppData()
    private let fileURL: URL

    init() {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        fileURL = paths[0].appendingPathComponent("flux_data.json")
    }

    func save(_ projects: [MainBubbleItem]) {
        do {
            let data = try JSONEncoder().encode(projects)
            try data.write(to: fileURL, options: [.atomic])
        } catch {
            print("Error saving data: \(error)")
        }
    }

    func load() -> [MainBubbleItem] {
        do {
            let data = try Data(contentsOf: fileURL)
            return try JSONDecoder().decode([MainBubbleItem].self, from: data)
        } catch {
            return []
        }
    }
}

// MARK: CreateTaskView (sheet)
struct CreateTaskView: View {
    @Binding var emojiInput: String
    @Binding var titleInput: String
    @Binding var editingProjectID: UUID?

    var onCreate: () -> Void
    var onSave: (UUID) -> Void
    var onCancel: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Text(editingProjectID == nil ? "New Bubble" : "Edit Bubble")
                .font(.title).bold()
                .padding()

            // Use the custom EmojiTextField which prefers the emoji keyboard
            EmojiTextField(text: $emojiInput, placeholder: "Icon (e.g. 🪐)")
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))

            TextField("Title", text: $titleInput)
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
            
            Spacer()

            HStack(spacing: 12) {
                Button(role: .cancel) { onCancel() } label: {
                    Text("Cancel").frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
                }

                Button(editingProjectID == nil ? "Create" : "Save") {
                    if let id = editingProjectID { onSave(id) } else { onCreate() }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(Color.accentColor.opacity(0.2)))
            }
            .padding(.horizontal)
        }
        .padding()
    }
}

// Custom UITextField subclass to force emoji keyboard
class EmojiOnlyTextField: UITextField {
    // Override the textInputMode to prefer the emoji keyboard when available.
    override var textInputMode: UITextInputMode? {
        for mode in UITextInputMode.activeInputModes {
            if mode.primaryLanguage == "emoji" { return mode }
        }
        return super.textInputMode
    }
}

// UIViewRepresentable wrapper for EmojiOnlyTextField
struct EmojiTextField: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String

    func makeUIView(context: Context) -> UITextField {
        let tf = EmojiOnlyTextField()
        tf.placeholder = placeholder
        tf.delegate = context.coordinator
        tf.borderStyle = .none
        tf.font = UIFont.preferredFont(forTextStyle: .body)
        tf.autocorrectionType = .no
        tf.autocapitalizationType = .none
        tf.addTarget(context.coordinator, action: #selector(Coordinator.textChanged(_:)), for: .editingChanged)
        // Ensure the field allows emoji input
        tf.keyboardType = .default
        return tf
    }

    func updateUIView(_ uiView: UITextField, context: Context) {
        if uiView.text != text {
            uiView.text = text
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject, UITextFieldDelegate {
        var parent: EmojiTextField
        init(_ parent: EmojiTextField) { self.parent = parent }

        @objc func textChanged(_ sender: UITextField) {
            parent.text = sender.text ?? ""
        }
    }
}

// MARK: HomeView
struct HomeView: View {
    @State private var projects: [MainBubbleItem] = AppData.shared.load()
    @State private var selectedProjectID: UUID?

    @State private var tempEmojiInput = ""
    @State private var tempTitleInput = ""
    @State private var editingProjectID: UUID?

    @State private var showProjectSheet: Bool = false
    @State private var contextProjectSnapshot: MainBubbleItem?

    @State private var animateRainbow: Bool = false
    @State private var showConfetti: Bool = false

    private let calmGradient = LinearGradient(colors: [Color("BGrad1"), Color("BGrad2")], startPoint: .top, endPoint: .bottom)
    private let rainGradient = LinearGradient(colors: [Color("BGrad3"), Color("BGrad4")], startPoint: .top, endPoint: .bottom)
    let rainbowGradient = LinearGradient(colors: [Color("BowGradient1"), Color("BowGradient2")], startPoint: .topLeading, endPoint: .bottomTrailing)
    private let mainBubbleSize: CGFloat = 160

    var body: some View {
        mainView
    }

    private var mainView: some View {
        NavigationStack {
            ZStack {
                backgroundLayer

                if projects.isEmpty && !showConfetti {
                    emptyStateView
                } else {
                    MetaBallCanvas(items: projects, sizeResolver: { _ in mainBubbleSize })
                        .ignoresSafeArea()

                    interactionLayer
                }
            }
            .navigationTitle("My Sky")
            .navigationDestination(isPresented: Binding(get: { selectedProjectID != nil }, set: { if !$0 { selectedProjectID = nil } })) {
                if let id = selectedProjectID, let index = projects.firstIndex(where: { $0.id == id }) {
                    TaskView(project: $projects[index], onDelete: {
                        projects.remove(at: index)
                        selectedProjectID = nil
                    })
                }
            }
            .toolbar { toolbarContent }
            .onChange(of: projects) { _, newValue in AppData.shared.save(newValue) }
            .onChange(of: tempEmojiInput) { oldValue, newValue in
                guard !newValue.isEmpty else { return }
                if let lastChar = newValue.last {
                    if lastChar.isEmoji {
                        if tempEmojiInput != String(lastChar) { tempEmojiInput = String(lastChar) }
                    } else { tempEmojiInput = oldValue }
                }
            }
            .displayConfetti(isActive: $showConfetti)
            .sheet(isPresented: $showProjectSheet) {
                CreateTaskView(emojiInput: $tempEmojiInput, titleInput: $tempTitleInput, editingProjectID: $editingProjectID, onCreate: {
                    createProject()
                    showProjectSheet = false
                }, onSave: { id in
                    updateProject(id)
                    showProjectSheet = false
                }, onCancel: { showProjectSheet = false })
                .presentationDetents([.medium])
            }
            .sheet(item: $contextProjectSnapshot) { project in
                ContextMenuView(
                    project: project,
                    tempEmojiInput: $tempEmojiInput,
                    tempTitleInput: $tempTitleInput,
                    editingProjectID: $editingProjectID,
                    contextProjectSnapshot: $contextProjectSnapshot,
                    showProjectSheet: $showProjectSheet,
                    onDelete: { id in triggerDeleteAnimation(for: id) }
                )
            }
        }
    }
}

// MARK: Subviews (file-scope extension)
private extension HomeView {
    @ViewBuilder
    var backgroundLayer: some View {
        calmGradient.ignoresSafeArea()

        rainGradient.ignoresSafeArea()
            .opacity(!projects.isEmpty && !showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 1.0), value: projects.isEmpty)

        if !projects.isEmpty && !showConfetti {
            VortexView(.rain) { Circle().fill(.white).frame(width: 32).tag("circle") }
                .ignoresSafeArea()
                .transition(.opacity.animation(.easeInOut(duration: 1.0)))
        }

        rainbowGradient
            .hueRotation(.degrees(animateRainbow ? 360 : 0))
            .ignoresSafeArea()
            .opacity(showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 0.5), value: showConfetti)
            .onChange(of: showConfetti) { _, isActive in
                if isActive {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) { animateRainbow = true }
                } else { animateRainbow = false }
            }
    }

    var emptyStateView: some View {
        ContentUnavailableView("No Bubbles", systemImage: "bubbles.and.sparkles", description: Text("Tap + to add a new Bubble."))
            .transition(.opacity)
    }

    @ViewBuilder
    var interactionLayer: some View {
        GeometryReader { proxy in
            let center = CGPoint(x: proxy.size.width / 2, y: proxy.size.height / 2)

            ZStack {
                ForEach(projects.indices, id: \.self) { index in
                    let projectBinding = $projects[index]
                    let item = projectBinding.wrappedValue

                    Circle()
                        .fill(Color.white.opacity(0.001))
                        .frame(width: mainBubbleSize, height: mainBubbleSize)
                        .offset(item.offset)
                        .position(center)
                        .gesture(
                            DragGesture()
                                .onChanged { gesture in
                                    let current = projectBinding.lastOffset.wrappedValue
                                    let t = gesture.translation
                                    projectBinding.offset.wrappedValue = CGSize(width: current.width + t.width, height: current.height + t.height)
                                }
                                .onEnded { _ in projectBinding.lastOffset.wrappedValue = projectBinding.offset.wrappedValue }
                        )
                        .highPriorityGesture(LongPressGesture(minimumDuration: 0.4).onEnded { _ in contextProjectSnapshot = item })
                        .onTapGesture { selectedProjectID = projectBinding.id.wrappedValue }

                    ZStack {
                        Text(item.emoji).font(.system(size: mainBubbleSize * 0.3)).offset(y: -45)
                        Text(item.title).font(.system(size: 16, weight: .bold, design: .rounded)).offset(y: 55)
                    }
                    .position(x: center.x + item.offset.width, y: center.y + item.offset.height)
                    .allowsHitTesting(false)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
    }

    @ToolbarContentBuilder
    var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .primaryAction) {
            Button(action: {
                tempEmojiInput = ""
                tempTitleInput = ""
                editingProjectID = nil
                showProjectSheet = true
            }) { Image(systemName: "plus") }
        }
    }
}

// MARK: Helpers
private extension HomeView {
    func createProject() {
        let emoji = tempEmojiInput.isEmpty ? "🪐" : tempEmojiInput
        let title = tempTitleInput.isEmpty ? "Project" : tempTitleInput
        let randomX = CGFloat.random(in: -100...100)
        let randomY = CGFloat.random(in: -200...200)
        let newProject = MainBubbleItem(title: title, emoji: emoji, subBubbles: [], offset: CGSize(width: randomX, height: randomY), lastOffset: CGSize(width: randomX, height: randomY))
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) { projects.append(newProject) }
    }

    func updateProject(_ id: UUID) {
        if let index = projects.firstIndex(where: { $0.id == id }) {
            projects[index].emoji = tempEmojiInput
            projects[index].title = tempTitleInput
        }
    }

    func triggerDeleteAnimation(for id: UUID) {
        withAnimation { showConfetti = true }
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) { projects.removeAll(where: { $0.id == id }) }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { withAnimation { showConfetti = false } }
    }
}

#Preview {
    HomeView()
}
