//
//  TaskView.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//

import SwiftUI
import FoundationModels
import Vortex

struct TaskView: View {
    @Binding var project: MainBubbleItem
    var onDelete: () -> Void
    
    @Environment(\.dismiss) var dismiss
    
    @State private var showAIStatusSheet = false
    
    var isAIGenerating: Bool {
        project.subBubbles.contains { $0.taskNote.isEmpty || $0.taskNote == "Thinking..." }
    }

    @State var animateRainbow: Bool = false
    @State var showConfetti = false
    @State var hasMovedPastFirstBubble = false
    @State private var selectedBubble: BubbleData?
    @State private var showEditAlert = false
    @State private var tempEditTitle = ""
    @State private var tempEditEmoji = ""
    @State private var snappingBubbleID: UUID? = nil
    @State var centerBubbleOffset: CGSize = .zero
    @State var centerBubbleLastOffset: CGSize = .zero
    @State private var centerScale: CGFloat = 1.0
    @State private var isHoldingCenter: Bool = false
    @State private var hapticTimer: Timer?
    @State private var hapticCounter = 0
    
    let snapThreshold: CGFloat = 100
    let standardSize: CGFloat = 140
    let maxStartSize: CGFloat = 220
    let numberEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    let calmGradient = LinearGradient(colors: [Color("BGrad1"), Color("BGrad2")], startPoint: .top, endPoint: .bottom)
    let rainGradient = LinearGradient(colors: [Color("BGrad3"), Color("BGrad4")], startPoint: .top, endPoint: .bottom)
    let rainbowGradient = LinearGradient(colors: [Color("BowGradient1"), Color("BowGradient2")], startPoint: .topLeading, endPoint: .bottomTrailing)
    
    var isStormy: Bool { project.subBubbles.isEmpty && !hasMovedPastFirstBubble }
    var isCloudy: Bool { !project.subBubbles.isEmpty }
    var currentMainSize: CGFloat {
        let maxBubbles: CGFloat = 10
        let totalShrinkAmount = maxStartSize - standardSize
        let shrinkPerBubble = totalShrinkAmount / maxBubbles
        let newSize = maxStartSize - (shrinkPerBubble * CGFloat(project.subBubbles.count))
        return max(newSize, standardSize)
    }
    
    var body: some View {
        contentView
            .navigationTitle(project.title)
            .toolbar {
                ToolbarItemGroup(placement: .primaryAction) {
                    Button { showAIStatusSheet = true } label: {
                        Image(systemName: isAIGenerating ? "sparkles" : "checkmark.seal.fill")
                            .symbolEffect(.pulse, isActive: isAIGenerating)
                    }
                    .tint(isAIGenerating ? .purple : .green)

                    if project.subBubbles.count < 10 {
                        Button { addNextSubBubble() } label: { Image(systemName: "plus") }
                    }
                }
            }
            // Provide a read-only Binding to AIStatusView since isAIGenerating is a computed property
            .sheet(isPresented: $showAIStatusSheet) {
                AIStatusView(isAIGenerating: Binding(get: { self.isAIGenerating }, set: { _ in }))
                    .presentationDetents([.medium])
            }
            .onChange(of: project.subBubbles.count) { oldCount, newCount in
                // Detect first transition from 0 -> 1
                if oldCount == 0 && newCount == 1 {
                    hasMovedPastFirstBubble = true
                }

                // Whenever the number of sub-bubbles changes, regenerate non-custom steps so the task splits progressively.
                updateAllBubblesContent()
            }
            .sheet(item: $selectedBubble) { bubble in
                SubTaskDetailView(
                    bubble: bubble,
                    onSave: { newText in
                        if let index = project.subBubbles.firstIndex(where: { $0.id == bubble.id }) {
                            project.subBubbles[index].taskNote = newText
                            project.subBubbles[index].isCustom = true
                            AppData.shared.save([project])
                        }
                    }, isPresented: Binding(
                        get: { selectedBubble != nil },
                        set: { if !$0 { selectedBubble = nil } }
                    )
                )
            }
            .presentationDetents([.medium, .large])
            .displayConfetti(isActive: $showConfetti)
            .onAppear {
                // If there is exactly one bubble and it's empty, generate the full task description.
                if !project.subBubbles.isEmpty {
                    // Trigger generation for non-custom or empty bubbles
                    updateAllBubblesContent()
                }
            }
    }

    // Extracted content to help the compiler type-check faster.
    private var contentView: some View {
        ZStack {
            backgroundView
            canvasView
            GeometryReader { proxy in
                centerAndSubBubblesLayer(proxy: proxy)
            }
        }
    }

    @ViewBuilder
    private var backgroundView: some View {
        calmGradient.ignoresSafeArea()

        rainGradient.ignoresSafeArea()
            .opacity(isStormy || isCloudy ? 1 : 0)
            .animation(.easeInOut(duration: 1.0), value: isStormy || isCloudy)

        Rectangle()
            .foregroundStyle(.white)
            .opacity(isCloudy ? 0.3 : 0)
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 1.0), value: isCloudy)

        if isStormy {
            VortexView(.rain) { Circle().fill(.white).frame(width: 32).tag("circle") }
                .ignoresSafeArea()
                .transition(.opacity.animation(.easeInOut(duration: 1.0)))
        }

        rainbowGradient
            .hueRotation(.degrees(animateRainbow ? 360 : 0))
            .ignoresSafeArea()
            .opacity(showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 0.5), value: showConfetti)
            .onChange(of: showConfetti) { _, isActive in
                if isActive {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) { animateRainbow = true }
                } else { animateRainbow = false }
            }
    }

    private var canvasView: some View {
        let centerItem = MainBubbleItem(title: project.title, emoji: project.emoji, subBubbles: [], offset: centerBubbleOffset)
        return MetaBallCanvasWithSubBubbles(
            centerItem: centerItem,
            subBubbles: project.subBubbles,
            centerSize: currentMainSize,
            subSize: standardSize,
            centerScale: centerScale * (isHoldingCenter ? 1.05 : 1.0),
            snappingBubbleID: snappingBubbleID
        )
        .ignoresSafeArea()
        .animation(.spring(response: 0.5, dampingFraction: 0.7), value: currentMainSize)
    }

    private func centerAndSubBubblesLayer(proxy: GeometryProxy) -> some View {
        let center = CGPoint(x: proxy.size.width / 2, y: proxy.size.height / 2)
        return ZStack {
            Text(project.emoji)
                .font(.system(size: currentMainSize * 0.3))
                .scaleEffect(centerScale * (isHoldingCenter ? 1.05 : 1.0))
                .position(x: center.x + centerBubbleOffset.width, y: center.y + centerBubbleOffset.height - 45)
                .allowsHitTesting(false)
                .animation(.spring(response: 0.5, dampingFraction: 0.7), value: currentMainSize)

            ForEach(project.subBubbles) { bubble in
                let isSnapping = bubble.id == snappingBubbleID

                Text(bubble.emoji)
                    .font(.system(size: standardSize * 0.3))
                    .scaleEffect(isSnapping ? 0.01 : 1.0)
                    .opacity(isSnapping ? 0 : 1.0)
                    .position(x: center.x + centerBubbleOffset.width + bubble.offset.width, y: center.y + centerBubbleOffset.height + bubble.offset.height - 45)
                    .allowsHitTesting(false)
                    .animation(.spring(response: 0.4, dampingFraction: 0.6), value: isSnapping)
                    .transition(.scale.combined(with: .opacity))
            }

            Circle()
                .frame(width: currentMainSize, height: currentMainSize)
                .opacity(0.001)
                .scaleEffect(centerScale * (isHoldingCenter ? 1.05 : 1.0))
                .offset(centerBubbleOffset)
                .position(center)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            let current = centerBubbleLastOffset
                            centerBubbleOffset = CGSize(width: current.width + value.translation.width, height: current.height + value.translation.height)
                        }
                        .onEnded { _ in centerBubbleLastOffset = centerBubbleOffset }
                )
                .onLongPressGesture(minimumDuration: 1.0, pressing: { isPressing in
                    withAnimation(.easeInOut(duration: 0.2)) { isHoldingCenter = isPressing }
                    if project.subBubbles.isEmpty {
                        if isPressing { startBuildingTension() } else { stopBuildingTension() }
                    }
                }) {
                    if project.subBubbles.isEmpty {
                        stopBuildingTension()
                        triggerCompletion()
                    }
                }

            ForEach($project.subBubbles) { $bubble in
                Circle()
                    .frame(width: standardSize, height: standardSize)
                    .opacity(0.001)
                    .offset(x: centerBubbleOffset.width + bubble.offset.width, y: centerBubbleOffset.height + bubble.offset.height)
                    .position(center)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                let current = bubble.lastOffset
                                bubble.offset = CGSize(width: current.width + value.translation.width, height: current.height + value.translation.height)
                            }
                            .onEnded { _ in
                                let distance = hypot(bubble.offset.width, bubble.offset.height)

                                if distance < snapThreshold {
                                    let generator = UIImpactFeedbackGenerator(style: .medium)
                                    generator.impactOccurred()

                                    snappingBubbleID = bubble.id

                                    withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { bubble.offset = .zero }

                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                        if let idx = project.subBubbles.firstIndex(where: { $0.id == bubble.id }) {
                                            project.subBubbles.remove(at: idx)
                                            snappingBubbleID = nil
                                            updateAllBubblesContent()
                                        }
                                    }
                                } else {
                                    bubble.lastOffset = bubble.offset
                                }
                            }
                    )
                    .onTapGesture { selectedBubble = bubble }
            }
        }
    }

    func addNextSubBubble() {
        guard project.subBubbles.count < 10 else { return }
        let index = project.subBubbles.count
        let emoji = index < numberEmojis.count ? numberEmojis[index] : "#"
        let randomX = CGFloat.random(in: -30...30)
        
        let newBubble = BubbleData(
            offset: CGSize(width: randomX, height: 80),
            lastOffset: CGSize(width: randomX, height: 80),
            emoji: emoji,
            taskNote: "",
            isCustom: false
        )
        
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            project.subBubbles.append(newBubble)
        }
        // Always regenerate non-custom bubbles whenever a new sub-bubble is added so the task splits progressively.
        updateAllBubblesContent()
    }
    
    func updateAllBubblesContent() {
        let bubbles = project.subBubbles
        let title = project.title
        Task {
            // Create a single session to keep the model context across steps
            let session = LanguageModelSession {
                """
                You are an assistant that splits a task into concise, actionable steps. Return exactly one plain-text step (no JSON, no markdown, no explanations, no numbering). When there is only 1 sub-bubble, return a single comprehensive step covering the whole task. As the number of sub-bubbles increases, split the task progressively into ordered steps across the bubbles. Keep responses under 30 words and return only the step text. If a step has been modified by the user (isCustom == true), do not overwrite it.
                """
            }

            for i in 0..<bubbles.count {
                // Use current up-to-date index lookup because project.subBubbles may change
                guard let currentIndex = project.subBubbles.firstIndex(where: { $0.id == bubbles[i].id }) else { continue }
                // Skip custom user-written steps
                if project.subBubbles[currentIndex].isCustom { continue }

                if project.subBubbles[currentIndex].taskNote.isEmpty || project.subBubbles[currentIndex].taskNote == "Thinking..." {
                    project.subBubbles[currentIndex].taskNote = "Thinking..."
                    await generateAIResponse(session: session, bubbleID: project.subBubbles[currentIndex].id, step: currentIndex+1, total: project.subBubbles.count, title: title)
                } else {
                    // If there is content but we still need to re-split (more than 1 bubble), request regeneration to split the whole task
                    if project.subBubbles.count > 1 {
                        project.subBubbles[currentIndex].taskNote = "Thinking..."
                        await generateAIResponse(session: session, bubbleID: project.subBubbles[currentIndex].id, step: currentIndex+1, total: project.subBubbles.count, title: title)
                    }
                }
            }
            AppData.shared.save([project])
        }
    }

    func generateAIResponse(session: LanguageModelSession, bubbleID: UUID, step: Int, total: Int, title: String) async {
        // Compose a prompt that instructs the model to split the task progressively.
        let prompt = "You are an assistant that splits a task into concise, actionable steps. Return exactly one plain-text step (no JSON, no markdown, no explanations, no numbering). When total=1 return the whole plan, otherwise return the text for this step only. Keep under 30 words. Plan project: '\(title)'. Step \(step) of \(total)."

        // Use the provided session to maintain context across multiple calls
        do {
            let response = try await session.respond(to: prompt)
            await MainActor.run {
                if let idx = project.subBubbles.firstIndex(where: { $0.id == bubbleID }) {
                    // Only write back if the bubble is not custom (a user-saved custom step)
                    if !project.subBubbles[idx].isCustom {
                        // Trim whitespace/newlines and ensure single-line output
                        let trimmed = response.content.trimmingCharacters(in: .whitespacesAndNewlines)
                        // In case model returns multiple lines, take first non-empty line
                        let firstLine = trimmed.split(separator: "\n").map { String($0) }.first ?? trimmed
                        project.subBubbles[idx].taskNote = firstLine
                        AppData.shared.save([project])
                    }
                }
            }
        } catch {
            print("AI Error: \(error)")
            // On failure we simply leave the 'Thinking...' placeholder or existing content. Optionally log.
        }
    }

    // Mirror-based deep search for the first non-empty String value.
    private func findFirstString(in value: Any) -> String? {
        let mirror = Mirror(reflecting: value)
        for child in mirror.children {
            if let s = child.value as? String, !s.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty {
                return s.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            }
            if let found = findFirstString(in: child.value) {
                return found
            }
        }
        return nil
    }
}

struct SubTaskDetailView: View {
    let bubble: BubbleData
    var onSave: (String) -> Void
    @Binding var isPresented: Bool
    @State var customStep: String = ""
    
    var body: some View {
        NavigationStack {
            switch SystemLanguageModel.default.availability {
            case .available:
                VStack(spacing: 20) {
                    Text(bubble.emoji)
                        .font(.system(size: 80))
                    
                    ScrollView {
                        Text(bubble.taskNote.isEmpty ? "Generating steps..." : bubble.taskNote)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                        
                        HStack {
                            TextField("Custom", text: $customStep)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 15)
                                        .foregroundStyle(Color.gray)
                                        .opacity(0.3)
                                )
                            
                            Button("Add") {
                                if !customStep.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                    onSave(customStep)
                                }
                                isPresented = false
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .foregroundStyle(Color.accentColor)
                                    .opacity(0.3)
                            )
                        }
                        .padding()
                    }
                    Spacer()
                }
                .padding()
                .navigationTitle("Step Info")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { isPresented = false }
                    }
                }
            case .unavailable(_):
                ContentUnavailableView("AI Unavailable", systemImage: "apple.intelligence.badge.xmark")
            }
        }
    }
}

extension TaskView {
    func startBuildingTension() {
        hapticCounter = 0
        hapticTimer?.invalidate()
        hapticTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            Task { @MainActor in
                hapticCounter += 1
                let style: UIImpactFeedbackGenerator.FeedbackStyle = hapticCounter < 4 ? .light : (hapticCounter < 8 ? .medium : .heavy)
                let gen = UIImpactFeedbackGenerator(style: style)
                gen.impactOccurred()
            }
        }
    }
    
    func stopBuildingTension() {
        hapticTimer?.invalidate()
        hapticTimer = nil
        hapticCounter = 0
    }
    
    func triggerCompletion() {
        let gen = UINotificationFeedbackGenerator()
        gen.notificationOccurred(.success)
        
        withAnimation(.easeOut(duration: 0.15)) {
            centerScale = 1.15
            showConfetti = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) {
                centerScale = 0.001
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                onDelete()
                dismiss()
            }
        }
    }
}
