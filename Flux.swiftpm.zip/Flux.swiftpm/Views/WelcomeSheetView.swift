//
//  WelcomeSheetView.swift
//  Flux
//
//  Created by Asia Ciafardini on 08/02/26.
//

import SwiftUI
import Vortex

struct PageInfo: Identifiable {
    let id: Double
    let label: String
    let image: ImageResource
}

let pages = [
    PageInfo(id: 1, label: "Sometimes tasks feel big and heavy.\nLike a Bubble in the storm.", image: .slide1),
    PageInfo(id: 2, label: "Bubbles don't have to stay big.\nSplit them to let the light back in.", image: .slide2),
    PageInfo(id: 3, label: "Pop your Bubble, and some friends will show up to celebrate!", image: .slide3)
]

let calmBackgroundGradient = LinearGradient(
    colors: [Color("BGrad1"), Color("BGrad2")],
    startPoint: .top, endPoint: .bottom)

let rainBackgroundGradient = LinearGradient(
    colors: [Color("BGrad3"), Color("BGrad4")],
    startPoint: .top, endPoint: .bottom)

let rainbowBackgroundGradient = LinearGradient(
    colors: [Color("BowGradient1"), Color("BowGradient2")],
    startPoint: .topLeading, endPoint: .bottomTrailing)

func FadeRainbowBG(showConfetti: Binding<Bool>) {
    //Keep confetti for 3 seconds, then fade out
    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
        //This withAnimation triggers the transitions defined in the ZStack
        withAnimation(.easeOut(duration: 1.0)) {
            showConfetti.wrappedValue = false
        }
    }
}

struct WelcomeSheetView: View {
    @Binding var isWelcomeSheetShowing: Bool
    @State var animateRainbow: Bool = false
    @State public var showConfetti: Bool = false
    @State var currentID: Double = 1
    
    var body: some View {
        ZStack {
            ZStack {
                if currentID == 1 {
                    rainBackgroundGradient.ignoresSafeArea()
                        .transition(.opacity)
                    
                    VortexView(.rain) {
                        Circle()
                            .fill(.white)
                            .frame(width: 32)
                            .tag("circle")
                    }
                    .ignoresSafeArea()
                    .transition(.opacity)
                    .onAppear {
                        // Reset states when returning to start
                        animateRainbow = false
                        showConfetti = false
                    }
                    
                } else if currentID == 2 {
                    rainBackgroundGradient.ignoresSafeArea()
                        .overlay {
                            Rectangle()
                                .foregroundStyle(.white).opacity(0.2)
                                .ignoresSafeArea()
                                .scaledToFill()
                        }
                        .transition(.opacity)
                        .onAppear {
                            animateRainbow = false
                            showConfetti = false
                        }
                    
                } else if currentID == 3 {
                    ZStack {
                        // Using if/else here so BOTH views participate in the transition system.
                        // When showConfetti toggles, one fades out while the other fades in.
                        if showConfetti {
                            rainbowBackgroundGradient
                                .hueRotation(.degrees(animateRainbow ? 360 : 0))
                                .ignoresSafeArea()
                                .transition(.opacity) // Fades Out when leaving
                        } else {
                            calmBackgroundGradient
                                .ignoresSafeArea()
                                .overlay {
                                    Rectangle()
                                        .foregroundStyle(.white).opacity(0.3)
                                        .ignoresSafeArea()
                                        .scaledToFill()
                                }
                                .transition(.opacity) // Fades In when arriving
                        }
                    }
                    .onAppear {
                        // Using withAnimation to ensure the initial appearance is smooth
                        withAnimation {
                            showConfetti = true
                        }
                        
                        // Start the rainbow color cycle
                        withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
                            animateRainbow = true
                        }
                        
                        // Queue the transition to the calm background
                        FadeRainbowBG(showConfetti: $showConfetti)
                    }
                }
            }
            // This animation modifier orchestrates the transitions (fade in/fade out)
            .animation(.easeInOut(duration: 1.0), value: showConfetti)
            .animation(.easeInOut(duration: 0.5), value: currentID)
            
            VStack {
                TabView (selection: $currentID) {
                    ForEach(pages) { page in
                        VStack {
                            Spacer()
                            
                            // Image
                            if page.id == 1 {
                                Image(page.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200, height: 200)
                                    .padding()
                            } else if page.id == 2 {
                                Image(page.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 300, height: 300)
                                    .padding()
                            } else if page.id == 3 {
                                Image(page.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 270, height: 270)
                                    .padding()
                            }
                            
                            Spacer()
                            
                            // Text
                            HStack {
                                VStack (alignment: .leading) {
                                    
                                    if page.id == 1 {
                                        Text("Welcome to Flux!")
                                            .font(.headline)
                                            .opacity(0.7)
                                    }
                                    
                                    Text(page.label)
                                        .font(.system(size: 26, weight: .heavy, design: .default))
                                    
                                    if page.id == 1 {
                                        Text("Press + to add a Bubble.")
                                            .font(.title2)
                                            .opacity(0.7)
                                    } else if page.id == 2 {
                                        Text("Press + again to split your Bubble.")
                                            .font(.title2)
                                            .opacity(0.7)
                                    } else if page.id == 3 {
                                        Text("Merge all Sub-Bubbles, then hold the main Bubble to pop it.")
                                            .font(.title2)
                                            .opacity(0.7)
                                    }
                                }
                                Spacer()
                            }
                            .padding()
                            .padding(.bottom, 45)
                        }
                        .tag(page.id)
                    }
                }
                .tabViewStyle(.page)
                .onAppear {
                    UIPageControl.appearance().currentPageIndicatorTintColor = .label
                    UIPageControl.appearance().pageIndicatorTintColor = .systemGray
                }
                
                Button {
                    // Logic to advance or dismiss
                    // Check if we are NOT on the last page yet
                    if currentID < Double(pages.count) {
                        withAnimation {
                            currentID += 1
                        }
                    } else {
                        // If we ARE on the last page, dismiss
                        isWelcomeSheetShowing.toggle()
                    }
                } label: {
                    HStack {
                        Spacer()
                        
                        // Custom label logic
                        // If it's the last page, say "Get Started", otherwise "Next"
                        Text(currentID == Double(pages.count) ? "Get Started" : "Next")
                            .font(.title3).bold()
                            .foregroundStyle(.white) // Ensure text remains visible
                            .padding()
                            
                        Spacer()
                    }
                    .background {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.accentColor)
                    }
                }
                .padding()
            }
            .interactiveDismissDisabled(true)
        }
        .displayConfetti(isActive: $showConfetti)
    }
}

#Preview {
    WelcomeSheetView(isWelcomeSheetShowing: .constant(true))
}
