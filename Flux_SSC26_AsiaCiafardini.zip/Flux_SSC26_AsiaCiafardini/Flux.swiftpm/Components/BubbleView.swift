//
// BubbleView.swift
// Flux
//
// Created by Asia Ciafardini on 10/02/26.
//

import SwiftUI
import MetalKit

// MARK: LiquidBlob
struct LiquidBlob: View {
    var size: CGFloat
    let circleCount = 6
    @State private var offsets: [CGSize] = Array(repeating: .zero, count: 6)
    @State private var scale: CGFloat = 0.01
    
    var body: some View {
        ZStack {
            Circle().fill(.white).frame(width: size, height: size)
            ForEach(0..<circleCount, id: \.self) { index in
                Circle().fill(.white)
                    .frame(width: size * 0.7, height: size * 0.7)
                    .offset(offsets[index])
            }
        }
        .scaleEffect(scale)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                scale = 1.0
            }
            for i in 0..<circleCount {
                withAnimation(.easeInOut(duration: Double.random(in: 2...4)).repeatForever()) {
                    offsets[i] = CGSize(
                        width: CGFloat.random(in: -size/4...size/4),
                        height: CGFloat.random(in: -size/4...size/4)
                    )
                }
            }
        }
    }
}

// MARK: MetalMetaBallView
private struct MetalMetaBallView: UIViewRepresentable {
    var items:         [MainBubbleItem]
    var sizeResolver:  (MainBubbleItem) -> CGFloat
    var scaleResolver: (MainBubbleItem) -> CGFloat
    var isPaused:      Bool

    // MARK: Coordinator
    final class Coordinator {
        let device:   MTLDevice
        let renderer: MetaBallRenderer?

        init() {
            guard let dev = MTLCreateSystemDefaultDevice() else {
                // Metal is unavailable. Degrade gracefully.
                print("[MetaBall] MTLCreateSystemDefaultDevice() returned nil — Metal unavailable.")
                self.device   = MTLCreateSystemDefaultDevice()!
                self.renderer = nil
                return
            }
            self.device = dev
            do {
                self.renderer = try MetaBallRenderer(device: dev)
            } catch {
                print("[MetaBall] Renderer setup failed: \(error.localizedDescription)")
                self.renderer = nil
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()

        // Only assign the delegate if we have a functioning renderer.
        view.device   = context.coordinator.device
        view.delegate = context.coordinator.renderer

        // Transparent background, the SwiftUI gradient layers show through.
        view.isOpaque        = false
        view.backgroundColor = .clear
        view.layer.isOpaque  = false

        // Match the pixel format expected by the pipeline state
        // and pre-multiplied alpha blending.
        view.colorPixelFormat = .bgra8Unorm
        view.clearColor       = MTLClearColorMake(0, 0, 0, 0)

        // Target 60 fps
        // view.preferredFramesPerSecond = 60

        // Continuous rendering
        view.isPaused              = isPaused
        view.enableSetNeedsDisplay = false

        // Ensure the drawable is auto-resized to match the view bounds.
        view.autoResizeDrawable = true

        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        uiView.isPaused = isPaused

        // Bail out early if the renderer could not be set up
        guard let renderer = context.coordinator.renderer else { return }

        renderer.updateSnapshots(
            items:              items,
            sizeResolver:       sizeResolver,
            scaleResolver:      scaleResolver,
            canvasSize:         uiView.bounds.size,
            contentScaleFactor: uiView.contentScaleFactor
        )
    }
}

// MARK: - MetalMetaBallViewWithSubBubbles
private struct MetalMetaBallViewWithSubBubbles: UIViewRepresentable {
    var centerItem:       MainBubbleItem
    var centerItemID:     UUID?
    var subBubbles:       [BubbleData]
    var centerSize:       CGFloat
    var subSize:          CGFloat
    var centerScale:      CGFloat
    var snappingBubbleID: UUID?
    var isPaused:         Bool

    // MARK: Coordinator
    final class Coordinator {
        let device:   MTLDevice
        let renderer: MetaBallRenderer?

        init() {
            guard let dev = MTLCreateSystemDefaultDevice() else {
                print("[MetaBall] MTLCreateSystemDefaultDevice() returned nil — Metal unavailable.")
                self.device   = MTLCreateSystemDefaultDevice()!
                self.renderer = nil
                return
            }
            self.device = dev
            do {
                self.renderer = try MetaBallRenderer(device: dev)
            } catch {
                print("[MetaBall] Renderer setup failed: \(error.localizedDescription)")
                self.renderer = nil
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device                   = context.coordinator.device
        view.delegate                 = context.coordinator.renderer
        view.isOpaque                 = false
        view.backgroundColor          = .clear
        view.layer.isOpaque           = false
        view.colorPixelFormat         = .bgra8Unorm
        view.clearColor               = MTLClearColorMake(0, 0, 0, 0)
        view.preferredFramesPerSecond = 60
        view.isPaused                 = isPaused
        view.enableSetNeedsDisplay    = false
        view.autoResizeDrawable       = true
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {
        uiView.isPaused = isPaused
        guard let renderer = context.coordinator.renderer else { return }

        renderer.updateSnapshotsWithSubBubbles(
            centerItem:         centerItem,
            centerItemStableID: centerItemID,   // Prevents wiggle
            subBubbles:         subBubbles,
            centerSize:         centerSize,
            subSize:            subSize,
            centerScale:        centerScale,
            snappingBubbleID:   snappingBubbleID,
            canvasSize:         uiView.bounds.size,
            contentScaleFactor: uiView.contentScaleFactor
        )
    }
}

// MARK: MetaBallCanvas
struct MetaBallCanvas: View {
    var isPaused: Bool = false
    var items: [MainBubbleItem]
    var sizeResolver: (MainBubbleItem) -> CGFloat
    // Allow the caller to provide a per-item scale (used when a bubble is being held)
    var scaleResolver: (MainBubbleItem) -> CGFloat = { _ in 1.0 }
    
    var body: some View {
        MetalMetaBallView(
            items:         items,
            sizeResolver:  sizeResolver,
            scaleResolver: scaleResolver,
            isPaused:      isPaused
        )
        // NOTE: Opacity is handled inside MetaBall.metal (outputOpacity = 0.4)
        .ignoresSafeArea()
    }
}

// MARK: MetaBallCanvasWithSubBubbles
struct MetaBallCanvasWithSubBubbles: View {
    var centerItem: MainBubbleItem
    var centerItemID: UUID? = nil
    var subBubbles: [BubbleData]
    var centerSize: CGFloat
    var subSize: CGFloat
    var centerScale: CGFloat
    var snappingBubbleID: UUID?
    
    var body: some View {
        MetalMetaBallViewWithSubBubbles(
            centerItem:       centerItem,
            centerItemID:     centerItemID,
            subBubbles:       subBubbles,
            centerSize:       centerSize,
            subSize:          subSize,
            centerScale:      centerScale,
            snappingBubbleID: snappingBubbleID,
            isPaused:         false
        )
        .ignoresSafeArea()
        // NOTE: Same as MetaBallCanvas, opacity baked into the shader.
        .animation(.spring(response: 0.4, dampingFraction: 0.7), value: snappingBubbleID)
    }
}
