//
//  ConfettiView.swift
//  Flux
//
//  Created by Asia Ciafardini on 06/02/26.
//
//  Based on the following tutorial by JC Builds:
//  medium.com/@jc_builds/swiftui-tutorials-designing-a-dynamic-confetti-effect-aa531c5adfb1
//

import SwiftUI

struct ConfettiView: View {
    @State private var animate = false
    @State private var xSpeed = Double.random(in: 0.7...2.0)
    @State private var zSpeed = Double.random(in: 1.0...2.0)
    @State private var anchor = CGFloat.random(in: 0...1).rounded()

    var body: some View {
        Rectangle()
            .fill([.orange, .green, .blue, .red, .yellow].randomElement() ?? .green)
            .frame(width: 14, height: 14)
            .onAppear { animate = true }
            .rotation3DEffect(.degrees(animate ? 360 : 0), axis: (x: 1, y: 0, z: 0))
            .animation(.linear(duration: xSpeed).repeatForever(autoreverses: false), value: animate)
            .rotation3DEffect(.degrees(animate ? 360 : 0),
                              axis: (x: 0, y: 0, z: 1),
                              anchor: UnitPoint(x: anchor, y: anchor))
            .animation(.linear(duration: zSpeed).repeatForever(autoreverses: false), value: animate)
    }
}

struct ConfettiContainerView: View {
    var count: Int = 50
    @State private var ySeed: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(0..<count, id: \.self) { _ in
                    ConfettiView()
                        .position(
                            x: CGFloat.random(in: 0...geo.size.width),
                            y: ySeed == 0 ? 0 : CGFloat.random(in: 0...geo.size.height)
                        )
                }
            }
            .ignoresSafeArea()
            .onAppear { ySeed = .random(in: 0...geo.size.height) }
        }
    }
}

struct DisplayConfettiModifier: ViewModifier {
    @Binding var isActive: Bool {
        didSet { if !isActive { opacity = 1 } }
    }
    @State private var opacity = 1.0 {
        didSet { if opacity == 0 { isActive = false } }
    }

    private let animationTime = 2.0
    private let fadeTime = 1.3

    func body(content: Content) -> some View {
            if #available(iOS 17, *) {
                content
                    .overlay(isActive ? ConfettiContainerView().opacity(opacity) : nil)
                    .sensoryFeedback(.success, trigger: isActive)
                    .task(id: isActive) {
                        if isActive { await sequence() }
                    }
            } else {
                content
                    .overlay(isActive ? ConfettiContainerView().opacity(opacity) : nil)
                    .task(id: isActive) {
                        if isActive { await sequence() }
                    }
            }
        }

    private func sequence() async {
        do {
            try await Task.sleep(nanoseconds: UInt64(animationTime * 1_000_000_000))
            withAnimation(.easeOut(duration: fadeTime)) { opacity = 0 }
        } catch {}
    }
}

extension View {
    func displayConfetti(isActive: Binding<Bool>) -> some View {
        modifier(DisplayConfettiModifier(isActive: isActive))
    }
}
