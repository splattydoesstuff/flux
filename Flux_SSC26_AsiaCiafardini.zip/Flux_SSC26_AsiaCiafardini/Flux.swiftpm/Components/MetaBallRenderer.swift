//
//  Metaballrenderer.swift
//  Flux
//
//  Created by Asia Ciafardini on 22/02/26.
//  bubble renderer. Wrote with the help of AI, based on my own SwiftUI based code. Helps reduce energy performance a bit. WILL lag if the AI is generating too much stuff

import Metal
import MetalKit
import QuartzCore
import SwiftUI

// This matches the data structure used inside the Metal shader file
struct MetaBallCircle {
    var position: SIMD2<Float>
    var radius: Float
    
    var scale: Float
    
    var opacity: Float
    
    var _pad: Float = 0
    
}

// Settings sent to the GPU to control the overall look
struct MetaBallUniforms {
    var resolution: SIMD2<Float>
    
    var blurSigma: Float
    
    var threshold: Float
    
    var outputOpacity: Float
    
    var circleCount: UInt32
    
    var _pad: SIMD2<Float> = .zero
}

// A simple "copy" of a bubble's state so the renderer can work safely
struct BubbleSnapshot {
    let id: UUID
    let offset: CGSize
    let size: CGFloat
    
    let targetScale: CGFloat
    
}

struct SubBubbleSnapshot {
    let id: UUID
    let offset: CGSize
    let isSnapping: Bool
    
}

private struct SpringState {
    var value: Float
    var velocity: Float
    var target: Float
    
    static let omega: Float = 2 * .pi / 0.5
    static let zeta: Float = 0.6
    static let omegaD: Float = omega * sqrt(1 - zeta * zeta)
    
    // Math to move the spring forward based on how much time passed
    mutating func advance(dt: Float) {
        let ω = SpringState.omega
        let ζ = SpringState.zeta
        let ωd = SpringState.omegaD
        
        let x0 = value - target
        let v0 = velocity
        let decay = exp(-ζ * ω * dt)
        let cosD = cos(ωd * dt)
        let sinD = sin(ωd * dt)
        
        let A = x0
        let B = (v0 + ζ * ω * x0) / ωd
        
        let newX = decay * (A * cosD + B * sinD)
        let newV = decay * ((-ζ * ω * A + B * ωd) * cosD + (-ζ * ω * B - A * ωd) * sinD)
        
        value = target + newX
        velocity = newV
    }
    
}

// Stores random movement patterns so a bubble's wiggle stays consistent
private struct BlobAnimationParams {
    struct SubCircle {
        let amplitudeX: Float
        
        let amplitudeY: Float
        let period: Float
        
        let phaseX: Float
        
        let phaseY: Float
    }
    let subCircles: [SubCircle]
}

// A custom random number generator to keep bubble movements predictable
private struct SeededRNG: RandomNumberGenerator {
    private var state: UInt64
    
    init(seed: Int) {
        state = seed == 0 ? 0xDEAD_BEEF_CAFE_1234 : UInt64(bitPattern: Int64(seed))
    }
    
    mutating func next() -> UInt64 {
        state ^= state << 13
        state ^= state >> 7
        state ^= state << 17
        return state
    }
    
}

enum MetaBallError: LocalizedError {
    case noMetalDevice
    case commandQueueFailed
    case defaultLibraryMissing
    case shaderFunctionMissing(String)
    case pipelineStateFailed(Error)
    
    var errorDescription: String? {
        switch self {
        case .noMetalDevice: return "Metal not supported."
        case .commandQueueFailed: return "Could not create command queue."
        case .defaultLibraryMissing: return "Shader library missing."
        case .shaderFunctionMissing(let name): return "Shader \(name) not found."
        case .pipelineStateFailed(let e): return "Pipeline error: \(e.localizedDescription)"
        }
    }
    
}

// The main engine that draws the "lava lamp" effect using Metal
final class MetaBallRenderer: NSObject, MTKViewDelegate {
    
    private let device: MTLDevice
    private let commandQueue: MTLCommandQueue
    private let pipelineState: MTLRenderPipelineState
    private var circleBuffer: MTLBuffer?
    
    private var snapshots: [BubbleSnapshot] = []
    private var subSnapshots: [SubBubbleSnapshot] = []
    private var centerSnapshot: BubbleSnapshot? = nil
    private var centerSize: Float = 0
    private var subSize: Float = 0
    private var contentScale: Float = 1
    private var canvasSize: CGSize = .zero
    private var renderMode: RenderMode = .items
    
    private enum RenderMode { case items, itemsWithSubBubbles }
    
    private var scaleSpringsByID: [UUID: SpringState] = [:]
    private var blobParamsByID: [UUID: BlobAnimationParams] = [:]
    private var centerSizeSpring: SpringState? = nil
    
    private let startTime: CFTimeInterval
    private var lastDrawTime: CFTimeInterval = 0
    
    init(device: MTLDevice) throws {
        self.device = device
        self.startTime = CACurrentMediaTime()
        
        guard let queue = device.makeCommandQueue() else { throw MetaBallError.commandQueueFailed }
        self.commandQueue = queue
        
        guard let library = device.makeDefaultLibrary() else { throw MetaBallError.defaultLibraryMissing }
        
        guard let vertexFn = library.makeFunction(name: "metaball_vertex"),
              let fragmentFn = library.makeFunction(name: "metaball_fragment") else {
            throw MetaBallError.shaderFunctionMissing("metaball_vertex/fragment")
        }
        
        let pipelineDesc = MTLRenderPipelineDescriptor()
        pipelineDesc.vertexFunction = vertexFn
        pipelineDesc.fragmentFunction = fragmentFn
        
        // Setup transparency blending
        let att = pipelineDesc.colorAttachments[0]!
        att.pixelFormat = .bgra8Unorm
        att.isBlendingEnabled = true
        att.rgbBlendOperation = .add
        att.alphaBlendOperation = .add
        att.sourceRGBBlendFactor = .one
        att.sourceAlphaBlendFactor = .one
        att.destinationRGBBlendFactor = .oneMinusSourceAlpha
        att.destinationAlphaBlendFactor = .oneMinusSourceAlpha
        
        self.pipelineState = try device.makeRenderPipelineState(descriptor: pipelineDesc)
        super.init()
    }
    
    // Updates the list of bubbles to draw
    func updateSnapshots(
        items: [MainBubbleItem],
        sizeResolver: (MainBubbleItem) -> CGFloat,
        scaleResolver: (MainBubbleItem) -> CGFloat,
        canvasSize: CGSize,
        contentScaleFactor: CGFloat
    ) {
        renderMode = .items
        self.canvasSize = canvasSize
        self.contentScale = Float(contentScaleFactor)
        centerSizeSpring = nil
        
        snapshots = items.map { item in
            BubbleSnapshot(
                id: item.id,
                offset: item.offset,
                size: sizeResolver(item),
                targetScale: scaleResolver(item)
            )
        }
        
        syncScaleSprings(to: snapshots.map { ($0.id, Float($0.targetScale)) })
        purgeStaleState(keepingIDs: Set(items.map(\.id)))
    }
    
    // Specialized update for bubbles that have smaller "sub-bubbles" attached
    func updateSnapshotsWithSubBubbles(
        centerItem: MainBubbleItem,
        centerItemStableID: UUID? = nil,
        subBubbles: [BubbleData],
        centerSize: CGFloat,
        subSize: CGFloat,
        centerScale: CGFloat,
        snappingBubbleID: UUID?,
        canvasSize: CGSize,
        contentScaleFactor: CGFloat
    ) {
        let stableID = centerItemStableID ?? centerItem.id
        renderMode = .itemsWithSubBubbles
        self.canvasSize = canvasSize
        self.contentScale = Float(contentScaleFactor)
        self.centerSize = Float(centerSize)
        self.subSize = Float(subSize)
        
        centerSnapshot = BubbleSnapshot(
            id: stableID,
            offset: centerItem.offset,
            size: centerSize,
            targetScale: centerScale
        )
        
        subSnapshots = subBubbles.map { sub in
            SubBubbleSnapshot(id: sub.id, offset: sub.offset, isSnapping: sub.id == snappingBubbleID)
        }
        
        var springTargets: [(UUID, Float)] = [(stableID, Float(centerScale))]
        springTargets += subBubbles.map { ($0.id, $0.id == snappingBubbleID ? 0.01 : 1.0) }
        syncScaleSprings(to: springTargets)
        
        let targetCenterSize = Float(centerSize)
        if centerSizeSpring == nil {
            centerSizeSpring = SpringState(value: targetCenterSize, velocity: 0, target: targetCenterSize)
        } else {
            centerSizeSpring!.target = targetCenterSize
        }
        
        purgeStaleState(keepingIDs: Set([stableID] + subBubbles.map(\.id)))
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
    
    // The heart of the renderer: called every frame to draw everything
    func draw(in view: MTKView) {
        guard !snapshots.isEmpty || centerSnapshot != nil,
              let drawable = view.currentDrawable,
              let renderPassDesc = view.currentRenderPassDescriptor,
              let cmdBuffer = commandQueue.makeCommandBuffer(),
              let encoder = cmdBuffer.makeRenderCommandEncoder(descriptor: renderPassDesc)
        else { return }
        
        renderPassDesc.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 0)
        renderPassDesc.colorAttachments[0].loadAction = .clear
        
        let now = CACurrentMediaTime()
        let dt = lastDrawTime == 0 ? 0 : Float(now - lastDrawTime)
        lastDrawTime = now
        let t = Float(now - startTime)
        
        // Move all the springs forward in time
        if dt > 0 {
            let frameTime = min(dt, 0.05)
            for key in scaleSpringsByID.keys {
                scaleSpringsByID[key]?.advance(dt: frameTime)
            }
            centerSizeSpring?.advance(dt: frameTime)
        }
        
        var circles: [MetaBallCircle] = []
        let scale = Float(view.contentScaleFactor)
        let canvasCenter = SIMD2<Float>(Float(view.drawableSize.width) / 2, Float(view.drawableSize.height) / 2)
        
        // Decide which circles to build based on the current mode
        switch renderMode {
        case .items:
            for snap in snapshots {
                buildCircles(for: snap, canvasCenter: canvasCenter, physicalScale: scale, time: t, into: &circles)
            }
        case .itemsWithSubBubbles:
            if let center = centerSnapshot {
                let animatedSize = CGFloat(centerSizeSpring?.value ?? Float(center.size))
                let sizedCenter = BubbleSnapshot(id: center.id, offset: center.offset, size: animatedSize, targetScale: center.targetScale)
                
                buildCircles(for: sizedCenter, canvasCenter: canvasCenter, physicalScale: scale, time: t, into: &circles)
                
                let mainCenter = SIMD2<Float>(canvasCenter.x + Float(center.offset.width) * scale, canvasCenter.y + Float(center.offset.height) * scale)
                for sub in subSnapshots {
                    let subSnap = BubbleSnapshot(id: sub.id, offset: sub.offset, size: CGFloat(self.subSize / scale), targetScale: CGFloat(sub.isSnapping ? 0.01 : 1.0))
                    buildSubCircles(for: subSnap, relativeTo: mainCenter, physicalScale: scale, time: t, into: &circles)
                }
            }
        }
        
        if circles.isEmpty {
            encoder.endEncoding()
            cmdBuffer.present(drawable)
            cmdBuffer.commit()
            return
        }
        
        // Upload the circle data to the GPU
        let circleBytes = circles.count * MemoryLayout<MetaBallCircle>.stride
        if circleBuffer == nil || circleBuffer!.length < circleBytes {
            circleBuffer = device.makeBuffer(length: max(circleBytes * 2, 1024), options: .storageModeShared)
        }
        
        circles.withUnsafeBytes { ptr in
            circleBuffer?.contents().copyMemory(from: ptr.baseAddress!, byteCount: circleBytes)
        }
        
        var uniforms = MetaBallUniforms(
            resolution: SIMD2(Float(view.drawableSize.width), Float(view.drawableSize.height)),
            blurSigma: 35.0 * scale,
            threshold: 0.5,
            outputOpacity: 0.4,
            circleCount: UInt32(circles.count)
        )
        
        // Run the GPU shader
        encoder.setRenderPipelineState(pipelineState)
        encoder.setVertexBytes(&uniforms, length: MemoryLayout<MetaBallUniforms>.stride, index: 0)
        encoder.setFragmentBytes(&uniforms, length: MemoryLayout<MetaBallUniforms>.stride, index: 0)
        encoder.setFragmentBuffer(circleBuffer, offset: 0, index: 1)
        encoder.drawPrimitives(type: .triangleStrip, vertexStart: 0, vertexCount: 4)
        
        encoder.endEncoding()
        cmdBuffer.present(drawable)
        cmdBuffer.commit()
    }
    
    // Creates the main circle and its 6 wobbling sub-circles
    private func buildCircles(for snap: BubbleSnapshot, canvasCenter: SIMD2<Float>, physicalScale: Float, time: Float, into circles: inout [MetaBallCircle]) {
        let physicalSize = Float(snap.size) * physicalScale
        let scaleVal = scaleSpringsByID[snap.id]?.value ?? Float(snap.targetScale)
        let opacity = max(0.0, min(1.0, (scaleVal - 0.01) / 0.34))
        
        let bx = canvasCenter.x + Float(snap.offset.width) * physicalScale
        let by = canvasCenter.y + Float(snap.offset.height) * physicalScale
        let bubbleCenter = SIMD2<Float>(bx, by)
        
        circles.append(MetaBallCircle(position: bubbleCenter, radius: physicalSize / 2, scale: scaleVal, opacity: opacity))
        
        let params = blobAnimationParams(for: snap.id, physicalSize: physicalSize)
        let subRadius = (physicalSize * 0.7) / 2
        
        for i in 0..<6 {
            let sub = params.subCircles[i]
            let ox = sub.amplitudeX * sin(2 * .pi * time / sub.period + sub.phaseX)
            let oy = sub.amplitudeY * sin(2 * .pi * time / sub.period + sub.phaseY)
            circles.append(MetaBallCircle(position: SIMD2(bx + ox, by + oy), radius: subRadius, scale: scaleVal, opacity: opacity))
        }
    }
    
    private func buildSubCircles(for snap: BubbleSnapshot, relativeTo parent: SIMD2<Float>, physicalScale: Float, time: Float, into circles: inout [MetaBallCircle]) {
        let physicalSize = Float(snap.size) * physicalScale
        let scaleVal = scaleSpringsByID[snap.id]?.value ?? Float(snap.targetScale)
        let opacity = max(0.0, min(1.0, (scaleVal - 0.01) / 0.34))
        
        let sx = parent.x + Float(snap.offset.width) * physicalScale
        let sy = parent.y + Float(snap.offset.height) * physicalScale
        let subCenter = SIMD2<Float>(sx, sy)
        
        circles.append(MetaBallCircle(position: subCenter, radius: physicalSize / 2, scale: scaleVal, opacity: opacity))
        
        let params = blobAnimationParams(for: snap.id, physicalSize: physicalSize)
        let subRadius = (physicalSize * 0.7) / 2
        
        for i in 0..<6 {
            let sub = params.subCircles[i]
            let ox = sub.amplitudeX * sin(2 * .pi * time / sub.period + sub.phaseX)
            let oy = sub.amplitudeY * sin(2 * .pi * time / sub.period + sub.phaseY)
            circles.append(MetaBallCircle(position: SIMD2(sx + ox, sy + oy), radius: subRadius, scale: scaleVal, opacity: opacity))
        }
    }
    
    // Calculates or retrieves the random movement "wiggle" data for a bubble
    private func blobAnimationParams(for id: UUID, physicalSize: Float) -> BlobAnimationParams {
        if let cached = blobParamsByID[id] { return cached }
        
        var rng = SeededRNG(seed: id.hashValue)
        let maxAmp = physicalSize / 4
        var subCircles: [BlobAnimationParams.SubCircle] = []
        
        for _ in 0..<6 {
            subCircles.append(.init(
                amplitudeX: Float.random(in: -maxAmp...maxAmp, using: &rng),
                amplitudeY: Float.random(in: -maxAmp...maxAmp, using: &rng),
                period: Float.random(in: 4...8, using: &rng),
                phaseX: Float.random(in: 0...(2 * .pi), using: &rng),
                phaseY: Float.random(in: 0...(2 * .pi), using: &rng)
            ))
        }
        
        let params = BlobAnimationParams(subCircles: subCircles)
        blobParamsByID[id] = params
        return params
    }
    
    // Keeps spring animations in sync with the current bubble list
    private func syncScaleSprings(to targets: [(UUID, Float)]) {
        for (id, target) in targets {
            if scaleSpringsByID[id] == nil {
                scaleSpringsByID[id] = SpringState(value: 0.01, velocity: 0, target: target)
            } else {
                scaleSpringsByID[id]!.target = target
            }
        }
    }
    
    // Cleans up memory for bubbles that no longer exist
    private func purgeStaleState(keepingIDs ids: Set<UUID>) {
        scaleSpringsByID = scaleSpringsByID.filter { ids.contains($0.key) }
        blobParamsByID = blobParamsByID.filter { ids.contains($0.key) }
    }
}
