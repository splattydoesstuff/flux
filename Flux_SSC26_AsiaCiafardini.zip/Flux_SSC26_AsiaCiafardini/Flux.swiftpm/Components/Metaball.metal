//
//  Metaball.metal
//  Flux
//
//  Created by Asia Ciafardini on 22/02/26.
//

#include <metal_stdlib>
using namespace metal;

// Defines the properties of a single bubble in the animation
struct MetaBallCircle {
    float2 position;
    float  radius;
    float  scale;
    float  opacity;
    float  _pad;
};

// Global settings passed from Swift to control the overall look
struct MetaBallUniforms {
    float2 resolution;
    float  blurSigma;
    float  threshold;
    float  outputOpacity;
    uint   circleCount;
    float2 _pad;
};

struct VertexOut {
    float4 clipPosition [[position]];
    float2 texCoord;
};

// Sets up a simple rectangle (two triangles) that covers the entire screen
vertex VertexOut metaball_vertex(
    uint vid [[vertex_id]],
    constant MetaBallUniforms &uniforms [[buffer(0)]]
) {
    constexpr float2 positions[4] = {
        float2(-1.0,  1.0),
        float2( 1.0,  1.0),
        float2(-1.0, -1.0),
        float2( 1.0, -1.0),
    };
    
    constexpr float2 uvs[4] = {
        float2(0.0, 0.0),
        float2(1.0, 0.0),
        float2(0.0, 1.0),
        float2(1.0, 1.0),
    };

    VertexOut out;
    out.clipPosition = float4(positions[vid], 0.0, 1.0);
    out.texCoord = uvs[vid];
    return out;
}

// A mathematical helper to smooth out the edges of the circles
inline float metal_erfc(float x) {
    const float ax = abs(x);
    constexpr float p  =  0.3275911f;
    constexpr float a1 =  0.254829592f;
    constexpr float a2 = -0.284496736f;
    constexpr float a3 =  1.421413741f;
    constexpr float a4 = -1.453152027f;
    constexpr float a5 =  1.061405429f;

    const float t = 1.0f / (1.0f + p * ax);
    const float poly = t * (a1 + t * (a2 + t * (a3 + t * (a4 + t * a5))));
    const float erfc_pos = poly * exp(-ax * ax);

    return x >= 0.0f ? erfc_pos : 2.0f - erfc_pos;
}

// Decides if a specific pixel is inside or outside a blob
fragment float4 metaball_fragment(
    VertexOut in [[stage_in]],
    constant MetaBallUniforms &uniforms [[buffer(0)]],
    constant MetaBallCircle *circles [[buffer(1)]]
) {
    float2 p = in.texCoord * uniforms.resolution;
    const float invSigmaSqrt2 = 1.0f / (uniforms.blurSigma * M_SQRT2_F);
    float fieldSum = 0.0f;

    // Loop through every circle and add its "influence" to this pixel
    for (uint i = 0; i < uniforms.circleCount; ++i) {
        MetaBallCircle c = circles[i];
        float effectiveRadius = c.radius * c.scale;
        
        // Calculate how far this pixel is from the circle
        float distToEdge = distance(p, c.position) - effectiveRadius;

        // Add the circle's glow/blur to the total field strength
        fieldSum += c.opacity * 0.5f * metal_erfc(distToEdge * invSigmaSqrt2);
    }

    // If the combined influence of all circles is too weak, make the pixel invisible
    if (fieldSum < uniforms.threshold) {
        return float4(0.0f);
    }

    // Draw the final shape with the requested transparency
    float a = uniforms.outputOpacity;
    return float4(a, a, a, a);
}
