//
//  AboutView.swift
//  Flux
//
//  Created by Asia Ciafardini on 03/02/26.
//  Not much to comment here we're talking about a simple view.

import SwiftUI

struct AboutView: View {
    @State var isWelcomeSheetShowing: Bool = false
    var body: some View {
        VStack {
            Spacer()
            
            Image("Icon")
                .resizable()
                .frame(width: 95, height: 95)
                .mask {
                    RoundedRectangle(cornerRadius: 17)
                }
            
            Text("Flux")
                .multilineTextAlignment(.center)
                .font(.largeTitle)
                .bold()
                .padding(.top)
            
            Text("A new way to organize your tasks.")
                .multilineTextAlignment(.center)
                .font(.headline).opacity(0.5)
                .padding(.bottom)
            
            Text("🎓 Submitted for Swift Student Challenge 2026")
                .multilineTextAlignment(.center)
                .font(.title3).bold()
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 30)
                        .foregroundStyle(.blue.opacity(0.5))
                )
                .padding(.bottom)
            
            VStack {
                Text("Built by Asia Ciafardini")
                    .multilineTextAlignment(.center)
                    .font(.title2).bold()
                
                Text("Student, Motion Designer, Self-Taught Coder.")
                    .multilineTextAlignment(.center)
                    .font(.subheadline)
                    .opacity(0.5)
                    .padding(.bottom)
                
                Text("You can learn more about me at the following [GitHub](https://github.com/splattydoesstuff) page. \n \n Any questions? Feel free to [email](mailto:techbysplatty@outlook.com) me!")
                    .multilineTextAlignment(.center)
                    .font(.body)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 30)
                    .foregroundStyle(.gray.opacity(0.2))
            )
            
            Spacer()
            
            Button {
                isWelcomeSheetShowing.toggle()
            } label: {
                Text("Replay Onboarding Screen")
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 30)
                            .foregroundStyle(.gray.opacity(0.2))
                    )
            }
            .padding()
            
            
        }
        .padding()
        .sheet(isPresented: $isWelcomeSheetShowing) {
            WelcomeSheetView(isWelcomeSheetShowing: $isWelcomeSheetShowing)
        }
    }
}

#Preview {
    AboutView()
}
