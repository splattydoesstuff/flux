//
//  ContextMenuView.swift
//  Flux
//
//  Created by Asia Ciafardini on 11/02/26.
//

import SwiftUI

struct ContextMenuView: View {
    // The project to operate on (passed in by the presenter)
    let project: MainBubbleItem

    // Bindings into parent view for populating the edit sheet
    @Binding var tempEmojiInput: String
    @Binding var tempDescriptionInput: String
    @Binding var tempTitleInput: String
    @Binding var editingProjectID: UUID?

    // Binding to the snapshot used by the presenter
    @Binding var contextProjectSnapshot: MainBubbleItem?

    // Binding to present the edit sheet from the parent
    @Binding var showProjectSheet: Bool

    // Deletion callback
    var onDelete: (UUID) -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Bubble Options")
                    .font(.title.weight(.heavy))
                    .padding(.leading)
                    .padding(.trailing)
                    .padding(.bottom)
                
                Text(project.emoji)
                    .font(.system(size: 48))
                Text(project.title)
                    .font(.title3.weight(.semibold))

                Divider()

                Button {
                    tempEmojiInput = project.emoji
                    tempTitleInput = project.title
                    tempDescriptionInput = project.taskDescription
                    editingProjectID = project.id
                    // Dismiss the options sheet by clearing the snapshot, then present editor
                    contextProjectSnapshot = nil
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        showProjectSheet = true
                    }
                } label: {
                    Text("Edit")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).foregroundColor(Color.gray.opacity(0.2)))
                }

                Button(role: .destructive) {
                    onDelete(project.id)
                    contextProjectSnapshot = nil
                } label: {
                    Text("Delete")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).foregroundColor(Color.red.opacity(0.1)))
                }
            }
            .presentationDetents([.medium])
            .padding(.leading)
            .padding(.trailing)
        }
    }
}

struct ContextMenuView_Previews: PreviewProvider {
    static var previews: some View {
        // sample project for preview
        let sample = MainBubbleItem(title: "Sample", emoji: "🪐", subBubbles: [], offset: .zero, lastOffset: .zero)
        ContextMenuView(
            project: sample,
            tempEmojiInput: .constant(sample.emoji),
            tempDescriptionInput: .constant(sample.taskDescription),
            tempTitleInput: .constant(sample.title),
            editingProjectID: .constant(nil),
            contextProjectSnapshot: .constant(sample),
            showProjectSheet: .constant(false),
            onDelete: { _ in }
        )
    }
}

#Preview {
    ContextMenuView_Previews.previews
}
