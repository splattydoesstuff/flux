//
//  HomeView.swift
//  Flux
//
//  Created by Asia Ciafardini on 03/02/26.
//

import SwiftUI
import SwiftData
import FoundationModels
import UIKit
import Observation

// MARK: Emoji Keeb
// This subclass forces the iOS keyboard to open the Emoji keyboard by default.
class UIEmojiTextField: UITextField {
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setEmoji() {
        _ = self.textInputMode
    }
    
    override var textInputContextIdentifier: String? {
           return ""
    }
    
    // We loop through available input modes and return the emoji one if found.
    override var textInputMode: UITextInputMode? {
        for mode in UITextInputMode.activeInputModes {
            if mode.primaryLanguage == "emoji" {
                self.keyboardType = .default
                return mode
            }
        }
        return nil
    }
}

// Bridges the UIKit Emoji field so we can use it inside a SwiftUI View.
struct EmojiTextField: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String = ""
    
    func makeUIView(context: Context) -> UIEmojiTextField {
        let emojiTextField = UIEmojiTextField()
        emojiTextField.placeholder = placeholder
        emojiTextField.text = text
        emojiTextField.delegate = context.coordinator
        emojiTextField.font = .systemFont(ofSize: 17)
        return emojiTextField
    }
    
    func updateUIView(_ uiView: UIEmojiTextField, context: Context) {
        uiView.text = text
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    class Coordinator: NSObject, UITextFieldDelegate {
        var parent: EmojiTextField
        
        init(parent: EmojiTextField) {
            self.parent = parent
        }
        
        func textFieldDidChangeSelection(_ textField: UITextField) {
            DispatchQueue.main.async { [weak self] in
                self?.parent.text = textField.text ?? ""
            }
        }
    }
}

// MARK: Keyboard Performance Optimization
// This prevents the app from stuttering when a user first taps an input. This is done by preloading the keyboard in the background. Unfortunately it will trigger a quick animation on startup, but it's the only way not to wait 10 seconds for it to load.
struct KeyboardPrewarmer: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let container = UIView()
        container.isHidden = true
        container.isUserInteractionEnabled = false

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let standard = UITextField()
            standard.alpha = 0
            container.addSubview(standard)
            standard.becomeFirstResponder()
            standard.resignFirstResponder()
            standard.removeFromSuperview()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let emoji = UIEmojiTextField()
                emoji.alpha = 0
                container.addSubview(emoji)
                emoji.becomeFirstResponder()
                emoji.resignFirstResponder()
                emoji.removeFromSuperview()
            }
        }
        return container
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}

// Simple check to see if a character is actually an emoji.
extension Character {
    var isEmoji: Bool {
        guard let scalar = unicodeScalars.first else { return false }
        return scalar.properties.isEmoji && (scalar.value >= 0x203C || scalar.properties.isEmojiPresentation)
    }
}

// MARK: Create/Edit Task Sheet
// The sheet for naming the bubble and picking an emoji, along with an optional description to change how the AI generates stuff.
struct CreateTaskView: View {
    @Binding var emojiInput: String
    @Binding var titleInput: String
    @Binding var descriptionInput: String
    @Binding var editingProjectID: UUID?

    var onCreate: () -> Void
    var onSave: (UUID) -> Void
    var onCancel: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            Text(editingProjectID == nil ? "New Bubble" : "Edit Bubble")
                .font(.title).bold()
                .padding()
            
            // This field ensures the user only enters one emoji.
            EmojiTextField(text: $emojiInput, placeholder: "Icon (e.g. 🪐)")
                .frame(height: 55)
                .padding(.horizontal)
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
                .onChange(of: emojiInput) { _ , newValue in
                    guard !newValue.isEmpty else { return }
                    if let lastChar = newValue.last {
                        if lastChar.isEmoji {
                            if emojiInput != String(lastChar) { emojiInput = String(lastChar) }
                        } else {
                            let filtered = newValue.filter { $0.isEmoji }
                            emojiInput = filtered
                        }
                    }
                }

            TextField("Title", text: $titleInput)
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
            
            TextField("Description (Optional)", text: $descriptionInput)
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))

            HStack(spacing: 12) {
                Button(role: .cancel) { onCancel() } label: {
                    Text("Cancel").frame(maxWidth: .infinity)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(.gray.opacity(0.2)))
                }

                Button(editingProjectID == nil ? "Create" : "Save") {
                    if let id = editingProjectID { onSave(id) } else { onCreate() }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(Color.accentColor.opacity(0.2)))
            }
            .padding(.horizontal)
        }
        .padding()
        .padding(.bottom)
    }
}

// MARK: Individual Bubble View
// Represents the main bubble on the screen with drag and long-press stuff implemented.
struct BubbleNodeView: View {
    @Bindable var project: MainBubbleItem
    let center: CGPoint
    let mainBubbleSize: CGFloat
    
    @Binding var holdingProjectID: UUID?
    @Binding var draggingProjectID: UUID?
    @Binding var contextProjectSnapshot: MainBubbleItem?
    @Binding var isHoldingMain: Bool
    @Binding var contextTask: Task<Void, Never>?
    @Binding var selectedProjectID: UUID?
    @Binding var removingProjectIDs: Set<UUID>
    
    var onSave: () -> Void
    
    private var isRemoving: Bool { removingProjectIDs.contains(project.id) }
    
    // Calculates where the bubble should be based on its saved offset.
    private var visualCenter: CGPoint {
        CGPoint(
            x: center.x + project.offset.width,
            y: center.y + project.offset.height
        )
    }
    
    var body: some View {
        ZStack {
            interactiveCircle
            
            VStack(spacing: 6) {
                Text(project.emoji).font(.system(size: 50))
                Text(project.title).font(.system(size: 18, weight: .bold, design: .rounded))
            }
            .allowsHitTesting(false)
        }
        .scaleEffect(
            isRemoving ? 0.01
            : (holdingProjectID == project.id ? (isHoldingMain ? 1.1 : 1.0) : 1.0)
        )
        .opacity(isRemoving ? 0 : 1)
        .animation(.spring(response: 0.5, dampingFraction: 0.6), value: isRemoving)
        .position(visualCenter)
    }
    
    // Handles the actual touching, dragging, and long-pressing of a bubble.
    private var interactiveCircle: some View {
        Circle()
            .fill(Color.white.opacity(0.001))
            .frame(width: mainBubbleSize, height: mainBubbleSize)
            .simultaneousGesture(dragGesture)
            .onLongPressGesture(minimumDuration: 1.0, pressing: { isPressing in
                handleLongPress(isPressing: isPressing)
            }, perform: {})
            .highPriorityGesture(tapGesture)
    }
    
    private var dragGesture: some Gesture {
        DragGesture(coordinateSpace: .global)
            .onChanged { gesture in
                let current = project.lastOffset
                let t = gesture.translation
                project.offset = CGSize(
                    width: current.width + t.width,
                    height: current.height + t.height
                )

                if draggingProjectID != project.id {
                    draggingProjectID = project.id
                }
                contextTask?.cancel()
            }
            .onEnded { _ in
                project.lastOffset = project.offset
                draggingProjectID = nil
                onSave()
            }
    }
    
    private var tapGesture: some Gesture {
        TapGesture().onEnded { _ in
            if contextProjectSnapshot == nil {
                selectedProjectID = project.id
            }
        }
    }
    
    // Stuff for the haptic feedback and showing the context menu after a long press.
    private func handleLongPress(isPressing: Bool) {
        if isPressing {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                holdingProjectID = project.id
                isHoldingMain = true
            }
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            
            contextTask = Task { @MainActor in
                do {
                    try await Task.sleep(for: .seconds(0.5))
                    if draggingProjectID == nil {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        contextProjectSnapshot = project
                    }
                } catch {
                    // Do nothing
                }
            }
        } else {
            contextTask?.cancel()
            withAnimation(.easeInOut(duration: 0.2)) { isHoldingMain = false }
            if contextProjectSnapshot == nil && holdingProjectID == project.id {
                holdingProjectID = nil
            }
        }
    }
}

// MARK: Main Sky View
struct HomeView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var projects: [MainBubbleItem]
    
    @State private var selectedProjectID: UUID?
    @State private var tempEmojiInput = ""
    @State private var tempTitleInput = ""
    @State private var tempDescriptionInput = ""
    @State private var editingProjectID: UUID?
    @State private var showProjectSheet: Bool = false
    @State private var contextProjectSnapshot: MainBubbleItem?
    @State private var animateRainbow: Bool = false
    @State private var showConfetti: Bool = false
    @State private var holdingProjectID: UUID? = nil
    @State private var mainCenterScale: CGFloat = 1.0
    @State private var isHoldingMain: Bool = false
    @State private var contextTask: Task<Void, Never>? = nil
    @State private var draggingProjectID: UUID? = nil
    @State private var removingProjectIDs: Set<UUID> = []

    private let calmGradient = LinearGradient(colors: [Color("BGrad1"), Color("BGrad2")], startPoint: .top, endPoint: .bottom)
    private let rainGradient = LinearGradient(colors: [Color("BGrad3"), Color("BGrad4")], startPoint: .top, endPoint: .bottom)
    let rainbowGradient = LinearGradient(colors: [Color("BowGradient1"), Color("BowGradient2")], startPoint: .topLeading, endPoint: .bottomTrailing)
    
    private let mainBubbleSize: CGFloat = 130

    var body: some View {
        mainView
            .background(KeyboardPrewarmer())
    }

    private var mainView: some View {
        NavigationStack {
            ZStack {
                backgroundLayer

                // The metaball effect that makes bubbles look like they are merging. Basically the core of the app.
                MetaBallCanvas(items: projects, sizeResolver: { _ in mainBubbleSize }, scaleResolver: { item in
                    if removingProjectIDs.contains(item.id) { return 0.01 }
                    if item.id == holdingProjectID { return mainCenterScale * (isHoldingMain ? 1.05 : 1.0) }
                    return 1.0
                })
                .ignoresSafeArea()

                if projects.isEmpty && !showConfetti {
                    emptyStateView
                } else {
                    interactionLayer
                }
            }
            .navigationTitle("My Sky")
            .navigationDestination(isPresented: Binding(
                get: { selectedProjectID != nil },
                set: { if !$0 { selectedProjectID = nil } }
            )) {
                if let id = selectedProjectID, let project = projects.first(where: { $0.id == id }) {
                    TaskViewBridge(
                        project: project,
                        onDelete: {
                            triggerDeleteAnimation(for: id)
                            selectedProjectID = nil
                        },
                        onSave: { try? modelContext.save() }
                    )
                }
            }
            .toolbar { toolbarContent }
            .displayConfetti(isActive: $showConfetti)
            .sheet(isPresented: $showProjectSheet) {
                CreateTaskView(
                    emojiInput: $tempEmojiInput,
                    titleInput: $tempTitleInput,
                    descriptionInput: $tempDescriptionInput,
                    editingProjectID: $editingProjectID,
                    onCreate: {
                        addProject(emoji: tempEmojiInput, title: tempTitleInput, description: tempDescriptionInput)
                        showProjectSheet = false
                    }, onSave: { id in
                        updateProject(id: id, emoji: tempEmojiInput, title: tempTitleInput, description: tempDescriptionInput)
                        showProjectSheet = false
                    }, onCancel: { showProjectSheet = false }
                )
                .presentationDetents([.medium])
            }
            .sheet(item: $contextProjectSnapshot) { project in
                ContextMenuView(
                    project: project,
                    tempEmojiInput: $tempEmojiInput,
                    tempDescriptionInput: $tempDescriptionInput, tempTitleInput: $tempTitleInput,
                    editingProjectID: $editingProjectID,
                    contextProjectSnapshot: $contextProjectSnapshot,
                    showProjectSheet: $showProjectSheet,
                    onDelete: { id in triggerDeleteAnimation(for: id) }
                )
            }
        }
    }
}

// MARK: UI Components Extension
private extension HomeView {
    @ViewBuilder
    var backgroundLayer: some View {
        calmGradient.ignoresSafeArea()

        rainGradient.ignoresSafeArea()
            .opacity(!projects.isEmpty && !showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 1.0), value: projects.isEmpty)
        
        // Adds rain when there are active bubbles.
        if !projects.isEmpty && !showConfetti {
            VortexView(.rain) { Circle().fill(.white).frame(width: 32).tag("circle") }
                .ignoresSafeArea()
        }
        
        // Rainbow background that appears during the "delete" animation.
        rainbowGradient
            .hueRotation(.degrees(animateRainbow ? 360 : 0))
            .ignoresSafeArea()
            .opacity(showConfetti ? 1 : 0)
            .onChange(of: showConfetti) { _, isActive in
                if isActive {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) { animateRainbow = true }
                } else { animateRainbow = false }
            }
    }

    var emptyStateView: some View {
        ContentUnavailableView("No Bubbles", systemImage: "bubbles.and.sparkles", description: Text("Tap + to add a new Bubble."))
    }

    @ViewBuilder
    var interactionLayer: some View {
        GeometryReader { proxy in
            let center = CGPoint(x: proxy.size.width / 2, y: proxy.size.height / 2)
            ZStack {
                ForEach(projects) { project in
                    BubbleNodeView(
                        project: project,
                        center: center,
                        mainBubbleSize: mainBubbleSize,
                        holdingProjectID: $holdingProjectID,
                        draggingProjectID: $draggingProjectID,
                        contextProjectSnapshot: $contextProjectSnapshot,
                        isHoldingMain: $isHoldingMain,
                        contextTask: $contextTask,
                        selectedProjectID: $selectedProjectID,
                        removingProjectIDs: $removingProjectIDs,
                        onSave: { try? modelContext.save() }
                    )
                }
            }
        }
        .ignoresSafeArea()
    }

    @ToolbarContentBuilder
    var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .primaryAction) {
            Button(action: {
                tempEmojiInput = ""
                tempTitleInput = ""
                tempDescriptionInput = ""
                editingProjectID = nil
                showProjectSheet = true
            }) { Image(systemName: "plus") }
        }
    }
}

// MARK: Data stuff
private extension HomeView {
    func addProject(emoji: String, title: String, description: String) {
        let finalEmoji = emoji.isEmpty ? "🪐" : emoji
        let finalTitle = title.isEmpty ? "Project" : title
        let randomX = CGFloat.random(in: -100...100)
        let randomY = CGFloat.random(in: -200...200)
        
        let newProject = MainBubbleItem(
            title: finalTitle,
            emoji: finalEmoji,
            taskDescription: description,
            subBubbles: [],
            offset: CGSize(width: randomX, height: randomY),
            lastOffset: CGSize(width: randomX, height: randomY)
        )
        
        modelContext.insert(newProject)
        try? modelContext.save()
    }
    
    func updateProject(id: UUID, emoji: String, title: String, description: String) {
        if let project = projects.first(where: { $0.id == id }) {
            project.emoji = emoji
            project.title = title
            project.taskDescription = description
            try? modelContext.save()
        }
    }
    
    func removeProject(id: UUID) {
        if let project = projects.first(where: { $0.id == id }) {
            modelContext.delete(project)
            try? modelContext.save()
        }
    }

    // Handles the pop animation and rainbow stuff when a bubble is deleted.
    func triggerDeleteAnimation(for id: UUID) {
        guard !removingProjectIDs.contains(id) else { return }
        
        withAnimation { showConfetti = true }
        withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
            removingProjectIDs.insert(id)
        }
        
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(0.7))
            removeProject(id: id)
            removingProjectIDs.remove(id)
            try? await Task.sleep(for: .seconds(2.0))
            withAnimation { showConfetti = false }
        }
    }
}

// Bridge to help SwiftData pass objects correctly into the subview.
struct TaskViewBridge: View {
    @Bindable var project: MainBubbleItem
    var onDelete: () -> Void
    var onSave: () -> Void
    
    var body: some View {
        TaskView(project: project, onDelete: onDelete, onSave: onSave)
    }
}

#Preview {
    HomeView()
        .modelContainer(for: MainBubbleItem.self, inMemory: true)
}
