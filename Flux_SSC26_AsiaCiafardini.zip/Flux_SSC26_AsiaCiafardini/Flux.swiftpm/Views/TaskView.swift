//
//  TaskView.swift
//  Flux
//
//  Created by Asia Ciafardini on 10/02/26.
//

import FoundationModels
import SwiftUI

// MARK: CanvasWrapper
// An equatable shell around MetaBallCanvasWithSubBubbles.
@MainActor
private struct CanvasWrapper: View, Equatable {
    let centerItem: MainBubbleItem
    let centerItemID: UUID
    let subBubbles: [BubbleData]
    let centerSize: CGFloat
    let subSize: CGFloat
    let centerScale: CGFloat
    let snappingBubbleID: UUID?

    // Snapshots
    let centerOffset: CGSize
    let bubbleIDs: [UUID]
    let bubbleOffsets: [CGSize]

    nonisolated static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.centerOffset == rhs.centerOffset &&
        lhs.centerItemID == rhs.centerItemID &&
        lhs.centerSize == rhs.centerSize &&
        lhs.subSize == rhs.subSize &&
        lhs.centerScale == rhs.centerScale &&
        lhs.snappingBubbleID == rhs.snappingBubbleID &&
        lhs.bubbleIDs == rhs.bubbleIDs &&
        lhs.bubbleOffsets == rhs.bubbleOffsets
    }

    var body: some View {
        MetaBallCanvasWithSubBubbles(
            centerItem: centerItem,
            centerItemID: centerItemID,
            subBubbles: subBubbles,
            centerSize: centerSize,
            subSize: subSize,
            centerScale: centerScale,
            snappingBubbleID: snappingBubbleID
        )
    }
}

// MARK: - SubBubbleView
// Each bubble is its own equatable view so SwiftUI considers them independently.
@MainActor
private struct SubBubbleView: View, Equatable {
    @Binding var offset: CGSize
    @Binding var lastOffset: CGSize

    let id: UUID
    let emoji: String
    let taskNote: String
    let standardSize: CGFloat
    let isSnapping: Bool
    let snapThreshold: CGFloat
    let onSnap: (UUID) -> Void
    let onDragEnd: () -> Void
    let onTap: () -> Void
    let currentOffset: CGSize

    nonisolated static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.id == rhs.id &&
        lhs.currentOffset == rhs.currentOffset &&
        lhs.emoji == rhs.emoji &&
        lhs.isSnapping == rhs.isSnapping
    }

    var body: some View {
        ZStack {
            Circle()
                .frame(width: standardSize, height: standardSize)
                .opacity(0.001)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Sub-task \(emoji)")
                .accessibilityValue(taskNote.isEmpty || taskNote == "Thinking..." ? "Generating step" : taskNote)
                .accessibilityAddTraits(.isButton)
                .accessibilityHint("Double tap to view or edit. Drag into the center to delete.")

            Text(emoji)
                .font(.system(size: standardSize * 0.4))
                .scaleEffect(isSnapping ? 0.01 : 1.0)
                .opacity(isSnapping ? 0 : 1.0)
                .accessibilityHidden(true)
        }
        .offset(offset)
        .animation(.spring(response: 0.4, dampingFraction: 0.6), value: isSnapping)
        .gesture(
            DragGesture(coordinateSpace: .global)
                .onChanged { value in
                    offset = CGSize(
                        width: lastOffset.width + value.translation.width,
                        height: lastOffset.height + value.translation.height
                    )
                }
                .onEnded { _ in
                    let distance = hypot(offset.width, offset.height)
                    if distance < snapThreshold {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                            offset = .zero
                        }
                        onSnap(id)
                    } else {
                        lastOffset = offset
                        onDragEnd()
                    }
                }
        )
        .onTapGesture { onTap() }
    }
}

// MARK: TaskView
struct TaskView: View {
    @Bindable var project: MainBubbleItem
    var onDelete: () -> Void
    var onSave: () -> Void

    @Environment(\.dismiss) var dismiss

    @State private var showAIStatusSheet = false

    // Avoids scanning subbubbles on every render tick.
    @State private var isAIGenerating: Bool = false

    // Single task handle so new requests cancel the previous run
    @State private var generationTask: Task<Void, Never>? = nil

    // Tracks which total count each bubble was last generated for, stored here so BubbleData can rest a bit
    @State private var generatedForTotal: [UUID: Int] = [:]

    @State var animateRainbow: Bool = false
    @State var showConfetti = false
    @State private var selectedBubble: BubbleData?
    @State private var snappingBubbleID: UUID? = nil
    @State var centerBubbleOffset: CGSize = .zero
    @State var centerBubbleLastOffset: CGSize = .zero
    @State private var centerScale: CGFloat = 1.0
    @State private var isHoldingCenter: Bool = false
    @State private var hapticCounter = 0
    @State private var tensionTask: Task<Void, Never>? = nil

    let snapThreshold: CGFloat = 100
    let standardSize: CGFloat = 110
    let maxStartSize: CGFloat = 175
    let numberEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]

    let calmGradient = LinearGradient(
        colors: [Color("BGrad1"), Color("BGrad2")],
        startPoint: .top,
        endPoint: .bottom
    )
    let rainGradient = LinearGradient(
        colors: [Color("BGrad3"), Color("BGrad4")],
        startPoint: .top,
        endPoint: .bottom
    )
    let rainbowGradient = LinearGradient(
        colors: [Color("BowGradient1"), Color("BowGradient2")],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    var isStormy: Bool {
        project.subBubbles.isEmpty && !project.hasMovedPastFirstBubble
    }
    var isCloudy: Bool { !project.subBubbles.isEmpty }

    // Main bubble shrinks slightly as subtasks accumulate
    var currentMainSize: CGFloat {
        let maxBubbles: CGFloat = 10
        let totalShrinkAmount = maxStartSize - standardSize
        let shrinkPerBubble = totalShrinkAmount / maxBubbles
        let newSize = maxStartSize - (shrinkPerBubble * CGFloat(project.subBubbles.count))
        return max(newSize, standardSize)
    }

    // Extracted so the gesture isn't re-created on every body run
    private var centerDragGesture: some Gesture {
        DragGesture(coordinateSpace: .global)
            .onChanged { value in
                centerBubbleOffset = CGSize(
                    width: centerBubbleLastOffset.width + value.translation.width,
                    height: centerBubbleLastOffset.height + value.translation.height
                )
            }
            .onEnded { _ in
                centerBubbleLastOffset = centerBubbleOffset
                onSave()
            }
    }

    var body: some View {
        contentView
            .navigationTitle(project.title)
            .toolbar {
                ToolbarItemGroup(placement: .primaryAction) {
                    Button {
                        showAIStatusSheet = true
                    } label: {
                        Image(systemName: isAIGenerating ? "sparkles" : "checkmark.seal.fill")
                            .symbolEffect(.pulse, isActive: isAIGenerating)
                    }
                    .tint(isAIGenerating ? .purple : .green)
                    .accessibilityLabel(isAIGenerating ? "AI is generating steps" : "AI generation complete")
                    .accessibilityHint("Double tap to view AI status.")

                    if project.subBubbles.count < 10 {
                        Button { addNextSubBubble() } label: {
                            Image(systemName: "plus")
                        }
                        .accessibilityLabel("Add Sub-Task")
                        .accessibilityHint("Creates a new sub-task bubble.")
                    }
                }
            }
            .sheet(isPresented: $showAIStatusSheet) {
                AIStatusView(
                    isAIGenerating: Binding(get: { self.isAIGenerating }, set: { _ in })
                )
                .presentationDetents([.medium])
            }
            .onChange(of: project.subBubbles.count) { oldCount, newCount in
                if oldCount == 0 && newCount > 0 {
                    project.hasMovedPastFirstBubble = true
                    onSave()
                }
                scheduleContentUpdate()
            }
            .sheet(item: $selectedBubble) { bubble in
                SubTaskDetailView(
                    bubble: bubble,
                    onCustomSave: { newText in
                        if let index = project.subBubbles.firstIndex(where: { $0.id == bubble.id }) {
                            project.subBubbles[index].taskNote = newText
                            project.subBubbles[index].isCustom = true
                            onSave()
                        }
                    },
                    isPresented: Binding(
                        get: { selectedBubble != nil },
                        set: { if !$0 { selectedBubble = nil } }
                    )
                )
            }
            .presentationDetents([.medium, .large])
            .displayConfetti(isActive: $showConfetti)
            .onAppear {
                if !project.subBubbles.isEmpty {
                    scheduleContentUpdate()
                }
            }
    }

    private var contentView: some View {
        ZStack {
            backgroundView
            canvasView
            GeometryReader { proxy in
                centerAndSubBubblesLayer(proxy: proxy)
            }
            .ignoresSafeArea()
        }
    }

    // Handles the "weather"
    @ViewBuilder
    private var backgroundView: some View {
        calmGradient.ignoresSafeArea()

        rainGradient.ignoresSafeArea()
            .opacity(isStormy || isCloudy || project.subBubbles.isEmpty && project.hasMovedPastFirstBubble ? 1 : 0)
            .animation(.easeInOut(duration: 1.0), value: isStormy || isCloudy)

        Rectangle()
            .foregroundStyle(.white)
            .opacity(isCloudy || project.subBubbles.isEmpty && project.hasMovedPastFirstBubble ? 0.3 : 0)
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 1.0), value: isCloudy)

        if isStormy {
            VortexView(.rain) {
                Circle().fill(.white).frame(width: 32).tag("circle")
            }
            .ignoresSafeArea()
            .transition(.opacity.animation(.easeInOut(duration: 1.0)))
            .accessibilityHidden(true)
        }

        rainbowGradient
            .hueRotation(.degrees(animateRainbow ? 360 : 0))
            .ignoresSafeArea()
            .opacity(showConfetti ? 1 : 0)
            .animation(.easeInOut(duration: 0.5), value: showConfetti)
            .onChange(of: showConfetti) { _, isActive in
                if isActive {
                    withAnimation(.linear(duration: 2.0).repeatForever(autoreverses: false)) {
                        animateRainbow = true
                    }
                } else {
                    animateRainbow = false
                }
            }
    }
    
    private var canvasView: some View {
        CanvasWrapper(
            centerItem: MainBubbleItem(
                title: project.title,
                emoji: project.emoji,
                subBubbles: [],
                offset: centerBubbleOffset
            ),
            centerItemID: project.id,
            subBubbles: project.subBubbles,
            centerSize: currentMainSize,
            subSize: standardSize,
            centerScale: centerScale * (isHoldingCenter ? 1.05 : 1.0),
            snappingBubbleID: snappingBubbleID,
            centerOffset: centerBubbleOffset,
            bubbleIDs: project.subBubbles.map(\.id),
            bubbleOffsets: project.subBubbles.map(\.offset)
        )
        .equatable()
        .ignoresSafeArea()
        .accessibilityHidden(true)
        .animation(.spring(response: 0.5, dampingFraction: 0.7), value: currentMainSize)
    }

    private func centerAndSubBubblesLayer(proxy: GeometryProxy) -> some View {
        let center = CGPoint(x: proxy.size.width / 2, y: proxy.size.height / 2)

        return ZStack {
            ZStack {
                Circle()
                    .frame(width: currentMainSize, height: currentMainSize)
                    .opacity(0.001)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(project.emoji) Main Task, \(project.title)")
                    .accessibilityAddTraits(.isButton)
                    .accessibilityHint("Drag to move. Long press to complete and delete the entire task.")

                Text(project.emoji)
                    .font(.system(size: 80))
                    .accessibilityHidden(true)
            }
            .scaleEffect(centerScale * (isHoldingCenter ? 1.05 : 1.0))
            .offset(centerBubbleOffset)
            .position(center)
            .animation(.spring(response: 0.5, dampingFraction: 0.7), value: currentMainSize)
            .gesture(centerDragGesture)
            .onLongPressGesture(
                minimumDuration: 1.0,
                pressing: { isPressing in
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isHoldingCenter = isPressing
                    }
                    if project.subBubbles.isEmpty {
                        if isPressing { startBuildingTension() }
                        else { stopBuildingTension() }
                    }
                }
            ) {
                if project.subBubbles.isEmpty {
                    stopBuildingTension()
                    triggerCompletion()
                }
            }
            
            ZStack {
                // ID-based ForEach, tries to avoid the "Index out of range" crash when a bubble is removed mid-animation
                ForEach(project.subBubbles, id: \.id) { bubble in
                    let bubbleID = bubble.id
                    
                    let offsetBinding = Binding<CGSize>(
                        get: {
                            project.subBubbles.first(where: { $0.id == bubbleID })?.offset
                                ?? bubble.offset
                        },
                        set: { newValue in
                            if let idx = project.subBubbles.firstIndex(where: { $0.id == bubbleID }) {
                                project.subBubbles[idx].offset = newValue
                            }
                        }
                    )
                    let lastOffsetBinding = Binding<CGSize>(
                        get: {
                            project.subBubbles.first(where: { $0.id == bubbleID })?.lastOffset
                                ?? bubble.lastOffset
                        },
                        set: { newValue in
                            if let idx = project.subBubbles.firstIndex(where: { $0.id == bubbleID }) {
                                project.subBubbles[idx].lastOffset = newValue
                            }
                        }
                    )

                    SubBubbleView(
                        offset: offsetBinding,
                        lastOffset: lastOffsetBinding,
                        id: bubbleID,
                        emoji: bubble.emoji,
                        taskNote: bubble.taskNote,
                        standardSize: standardSize,
                        isSnapping: bubbleID == snappingBubbleID,
                        snapThreshold: snapThreshold,
                        onSnap: handleSnap,
                        onDragEnd: onSave,
                        onTap: {
                            guard let live = project.subBubbles.first(where: { $0.id == bubbleID }) else { return }
                            selectedBubble = live
                        },
                        currentOffset: bubble.offset
                    )
                    .equatable()
                }
            }
            .offset(x: centerBubbleOffset.width, y: centerBubbleOffset.height)
            .position(center)
        }
    }

    // Delays snap deletion so the shrink animation has room to breathe
    private func handleSnap(_ id: UUID) {
        snappingBubbleID = id
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(0.4))
            if let idx = project.subBubbles.firstIndex(where: { $0.id == id }) {
                project.subBubbles.remove(at: idx)
                snappingBubbleID = nil
                scheduleContentUpdate()
                onSave()
            }
        }
    }

    func addNextSubBubble() {
        guard project.subBubbles.count < 10 else { return }
        let index = project.subBubbles.count
        let emoji = index < numberEmojis.count ? numberEmojis[index] : "#"
        let randomX = CGFloat.random(in: -30...30)

        let newBubble = BubbleData(
            offset: CGSize(width: randomX, height: 80),
            lastOffset: CGSize(width: randomX, height: 80),
            emoji: emoji,
            taskNote: "",
            isCustom: false
        )

        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            project.subBubbles.append(newBubble)
        }
    }
    
    func scheduleContentUpdate() {
            generationTask?.cancel()
            isAIGenerating = true
            
            generationTask = Task(priority: .utility) {
                try? await Task.sleep(for: .milliseconds(150))
                guard !Task.isCancelled else { return }
                await updateAllBubblesContent()
            }
        }

        func updateAllBubblesContent() async {
            guard !Task.isCancelled else { return }
            let total = project.subBubbles.count
            
            guard total > 0 else {
                await MainActor.run { isAIGenerating = false }
                return
            }

            let bubbleIDs = project.subBubbles.map(\.id)

            // Skip bubbles already generated for this count
            let pendingIDs = bubbleIDs.filter { id in
                guard let bubble = project.subBubbles.first(where: { $0.id == id }) else { return false }
                return !bubble.isCustom && (bubble.taskNote.isEmpty || generatedForTotal[id] != total)
            }

            guard !pendingIDs.isEmpty else {
                await MainActor.run { isAIGenerating = false }
                return
            }
            
            await MainActor.run {
                for id in pendingIDs {
                    if let idx = project.subBubbles.firstIndex(where: { $0.id == id }) {
                        project.subBubbles[idx].taskNote = "Thinking..."
                    }
                }
            }

            let title = project.title
            let description = project.taskDescription
            
            // Move the description into the System Prompt so it becomes (well, at least it tries to) a hard rule for the AI
            let systemInstruction = """
            You are an intelligence living in a sky full of bubbles. You help the user manage their schedule by breaking down a main task into sequential steps.
            Main Task: '\(title)'
            \(description.isEmpty ? "" : "Additional user context to include: '\(description)'. You should base all your generated steps on this topic strictly on this context.")
            
            Rules:
            - Return exactly one plain-text step.
            - Keep responses under 30 words.
            - Do not use markdown, JSON, or numbering.
            """

            let session = LanguageModelSession { systemInstruction }
            var results: [(id: UUID, text: String)] = []

            for (stepIndex, bubbleID) in bubbleIDs.enumerated() {
                guard !Task.isCancelled else { break }
                guard pendingIDs.contains(bubbleID) else { continue }

                if let text = await generateStep(
                    session: session,
                    step: stepIndex + 1,
                    total: total
                ) {
                    results.append((id: bubbleID, text: text))
                }
                await Task.yield()
            }
            
            await MainActor.run {
                for result in results {
                    if let idx = project.subBubbles.firstIndex(where: { $0.id == result.id }),
                       !project.subBubbles[idx].isCustom
                    {
                        project.subBubbles[idx].taskNote = result.text
                        generatedForTotal[result.id] = total
                    }
                }
                
                // Only turn the icon green if the task finished naturally without being cancelled
                if !Task.isCancelled {
                    isAIGenerating = false
                }
                
                onSave()
            }
        }
        
        // Simplified this function since the System Prompt now handles the heavy lifting
        private func generateStep(session: LanguageModelSession, step: Int, total: Int) async -> String? {
            guard !Task.isCancelled else { return nil }
            
            let prompt = "Generate step \(step) of \(total). Keep under 30 words and return ONLY the step itself, without any other content such as your comments."

            do {
                let response = try await session.respond(to: prompt)
                guard !Task.isCancelled else { return nil }
                let trimmed = response.content.trimmingCharacters(in: .whitespacesAndNewlines)
                return trimmed.split(separator: "\n").map { String($0) }.first ?? trimmed
            } catch is CancellationError {
                return nil
            } catch {
                print("AI Error: \(error)")
                return nil
            }
        }
}

// MARK: SubTaskDetailView
struct SubTaskDetailView: View {
    let bubble: BubbleData
    var onCustomSave: (String) -> Void
    @Binding var isPresented: Bool
    @State var customStep: String = ""

    var body: some View {
        NavigationStack {
            switch SystemLanguageModel.default.availability {
            case .available:
                VStack(spacing: 20) {
                    Text(bubble.emoji).font(.system(size: 80))

                    ScrollView {
                        Text(bubble.taskNote.isEmpty ? "Generating steps..." : bubble.taskNote)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)

                        HStack {
                            TextField("Custom", text: $customStep)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(Color.gray).opacity(0.3))
                                .accessibilityLabel("Custom Step Input")

                            Button("Add") {
                                if !customStep.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                    onCustomSave(customStep)
                                }
                                isPresented = false
                            }
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 15).foregroundStyle(Color.accentColor).opacity(0.3))
                        }
                        .padding()
                    }
                    Spacer()
                }
                .padding()
                .navigationTitle("Step Info")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { isPresented = false }
                    }
                }
            case .unavailable(_):
                ContentUnavailableView("AI Unavailable", systemImage: "apple.intelligence.badge.xmark")
            }
        }
    }
}

// MARK: Tension+Completion
extension TaskView {
    // Vibrates faster and harder as you hold
    func startBuildingTension() {
        hapticCounter = 0
        tensionTask?.cancel()

        tensionTask = Task { @MainActor in
            while !Task.isCancelled {
                hapticCounter += 1
                let style: UIImpactFeedbackGenerator.FeedbackStyle =
                    hapticCounter < 4 ? .light : (hapticCounter < 8 ? .medium : .heavy)
                UIImpactFeedbackGenerator(style: style).impactOccurred()
                try? await Task.sleep(for: .seconds(0.1))
            }
        }
    }

    func stopBuildingTension() {
        tensionTask?.cancel()
        tensionTask = nil
        hapticCounter = 0
    }

    // Pops the bubble, shows confetti, closes the view. hooray!
    func triggerCompletion() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)

        withAnimation(.easeOut(duration: 0.15)) {
            centerScale = 1.15
            showConfetti = true
        }

        Task { @MainActor in
            try? await Task.sleep(for: .seconds(0.15))
            withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) {
                centerScale = 0.001
            }
            try? await Task.sleep(for: .seconds(1.5))
            onDelete()
            dismiss()
        }
    }
}
